Demolition Media Hap Pro Sync for Unity - v2.0.1
Copyright 2017-2022 Demolition Studios. All Rights Reserved.

Note: if you use this plugin on multiple projects/machines: 
      an individual license per each project per each machine is required. 

In order to get the example scenes working, download the sample videos archive via the link below  and put the SampleVideos folder from it to Assets/StreamingAssets. Download link: https://www.dropbox.com/s/cothvfdylt330yw/SampleVideos.zip?dl=1

Documentation, demo version and issue tracker: https://github.com/DemolitionStudios/DemolitionMediaHapProSync