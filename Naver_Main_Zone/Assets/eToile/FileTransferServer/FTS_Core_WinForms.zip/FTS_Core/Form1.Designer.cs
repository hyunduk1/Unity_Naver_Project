﻿namespace FTS_Core
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxFtsPort = new System.Windows.Forms.TextBox();
            this.buttonFtsOpen = new System.Windows.Forms.Button();
            this.buttonDiscover = new System.Windows.Forms.Button();
            this.textBoxFile = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonDownload = new System.Windows.Forms.Button();
            this.buttonUpload = new System.Windows.Forms.Button();
            this.textBoxView = new System.Windows.Forms.TextBox();
            this.buttonClearView = new System.Windows.Forms.Button();
            this.buttonDisconnect = new System.Windows.Forms.Button();
            this.comboBoxDevices = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.buttonResetList = new System.Windows.Forms.Button();
            this.checkBoxEnabled = new System.Windows.Forms.CheckBox();
            this.labelDName = new System.Windows.Forms.Label();
            this.labelDProgress = new System.Windows.Forms.Label();
            this.labelDStatus = new System.Windows.Forms.Label();
            this.labelInfoRes = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelDChunk = new System.Windows.Forms.Label();
            this.labelDRetries = new System.Windows.Forms.Label();
            this.labelRequests = new System.Windows.Forms.Label();
            this.labelUploads = new System.Windows.Forms.Label();
            this.textBoxRemoteIP = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelUName = new System.Windows.Forms.Label();
            this.labelUProgress = new System.Windows.Forms.Label();
            this.labelUStatus = new System.Windows.Forms.Label();
            this.labelUChunk = new System.Windows.Forms.Label();
            this.buttonBroadcast = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonChunkSize = new System.Windows.Forms.Button();
            this.labelChunkSize = new System.Windows.Forms.Label();
            this.textBoxChunkSize = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(156, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Port";
            // 
            // textBoxFtsPort
            // 
            this.textBoxFtsPort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxFtsPort.Location = new System.Drawing.Point(188, 19);
            this.textBoxFtsPort.MaxLength = 5;
            this.textBoxFtsPort.Name = "textBoxFtsPort";
            this.textBoxFtsPort.Size = new System.Drawing.Size(75, 20);
            this.textBoxFtsPort.TabIndex = 1;
            this.textBoxFtsPort.Text = "60000";
            // 
            // buttonFtsOpen
            // 
            this.buttonFtsOpen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonFtsOpen.Location = new System.Drawing.Point(395, 17);
            this.buttonFtsOpen.Name = "buttonFtsOpen";
            this.buttonFtsOpen.Size = new System.Drawing.Size(75, 23);
            this.buttonFtsOpen.TabIndex = 4;
            this.buttonFtsOpen.Text = "Open";
            this.buttonFtsOpen.UseVisualStyleBackColor = true;
            this.buttonFtsOpen.Click += new System.EventHandler(this.ButtonFtsOpen_Click);
            // 
            // buttonDiscover
            // 
            this.buttonDiscover.Location = new System.Drawing.Point(42, 45);
            this.buttonDiscover.Name = "buttonDiscover";
            this.buttonDiscover.Size = new System.Drawing.Size(75, 23);
            this.buttonDiscover.TabIndex = 6;
            this.buttonDiscover.Text = "Discover";
            this.buttonDiscover.UseVisualStyleBackColor = true;
            this.buttonDiscover.Click += new System.EventHandler(this.ButtonDiscover_Click);
            // 
            // textBoxFile
            // 
            this.textBoxFile.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxFile.Location = new System.Drawing.Point(42, 74);
            this.textBoxFile.Name = "textBoxFile";
            this.textBoxFile.Size = new System.Drawing.Size(266, 20);
            this.textBoxFile.TabIndex = 7;
            this.textBoxFile.Text = "capture.jpg";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "File";
            // 
            // buttonDownload
            // 
            this.buttonDownload.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDownload.Location = new System.Drawing.Point(314, 72);
            this.buttonDownload.Name = "buttonDownload";
            this.buttonDownload.Size = new System.Drawing.Size(75, 23);
            this.buttonDownload.TabIndex = 9;
            this.buttonDownload.Text = "Download";
            this.buttonDownload.UseVisualStyleBackColor = true;
            this.buttonDownload.Click += new System.EventHandler(this.ButtonDownload_Click);
            // 
            // buttonUpload
            // 
            this.buttonUpload.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonUpload.Location = new System.Drawing.Point(395, 72);
            this.buttonUpload.Name = "buttonUpload";
            this.buttonUpload.Size = new System.Drawing.Size(75, 23);
            this.buttonUpload.TabIndex = 10;
            this.buttonUpload.Text = "Send";
            this.buttonUpload.UseVisualStyleBackColor = true;
            this.buttonUpload.Click += new System.EventHandler(this.ButtonUpload_Click);
            // 
            // textBoxView
            // 
            this.textBoxView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxView.CausesValidation = false;
            this.textBoxView.Location = new System.Drawing.Point(13, 195);
            this.textBoxView.Multiline = true;
            this.textBoxView.Name = "textBoxView";
            this.textBoxView.ReadOnly = true;
            this.textBoxView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxView.Size = new System.Drawing.Size(457, 207);
            this.textBoxView.TabIndex = 12;
            // 
            // buttonClearView
            // 
            this.buttonClearView.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClearView.Location = new System.Drawing.Point(476, 379);
            this.buttonClearView.Name = "buttonClearView";
            this.buttonClearView.Size = new System.Drawing.Size(75, 23);
            this.buttonClearView.TabIndex = 13;
            this.buttonClearView.Text = "Clear view";
            this.buttonClearView.UseVisualStyleBackColor = true;
            this.buttonClearView.Click += new System.EventHandler(this.ButtonClearView_Click);
            // 
            // buttonDisconnect
            // 
            this.buttonDisconnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDisconnect.Location = new System.Drawing.Point(476, 17);
            this.buttonDisconnect.Name = "buttonDisconnect";
            this.buttonDisconnect.Size = new System.Drawing.Size(75, 23);
            this.buttonDisconnect.TabIndex = 14;
            this.buttonDisconnect.Text = "Close";
            this.buttonDisconnect.UseVisualStyleBackColor = true;
            this.buttonDisconnect.Click += new System.EventHandler(this.ButtonDisconnect_Click);
            // 
            // comboBoxDevices
            // 
            this.comboBoxDevices.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxDevices.FormattingEnabled = true;
            this.comboBoxDevices.Location = new System.Drawing.Point(290, 46);
            this.comboBoxDevices.Name = "comboBoxDevices";
            this.comboBoxDevices.Size = new System.Drawing.Size(180, 21);
            this.comboBoxDevices.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Name";
            // 
            // textBoxName
            // 
            this.textBoxName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxName.Location = new System.Drawing.Point(51, 19);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(99, 20);
            this.textBoxName.TabIndex = 17;
            this.textBoxName.TextChanged += new System.EventHandler(this.TextBoxName_TextChanged);
            // 
            // buttonResetList
            // 
            this.buttonResetList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonResetList.Location = new System.Drawing.Point(476, 45);
            this.buttonResetList.Name = "buttonResetList";
            this.buttonResetList.Size = new System.Drawing.Size(75, 23);
            this.buttonResetList.TabIndex = 18;
            this.buttonResetList.Text = "Reset list";
            this.buttonResetList.UseVisualStyleBackColor = true;
            this.buttonResetList.Click += new System.EventHandler(this.ButtonResetList_Click);
            // 
            // checkBoxEnabled
            // 
            this.checkBoxEnabled.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxEnabled.AutoSize = true;
            this.checkBoxEnabled.Location = new System.Drawing.Point(270, 21);
            this.checkBoxEnabled.Name = "checkBoxEnabled";
            this.checkBoxEnabled.Size = new System.Drawing.Size(98, 17);
            this.checkBoxEnabled.TabIndex = 19;
            this.checkBoxEnabled.Text = "Server enabled";
            this.checkBoxEnabled.UseVisualStyleBackColor = true;
            this.checkBoxEnabled.CheckedChanged += new System.EventHandler(this.CheckBoxEnabled_CheckedChanged);
            // 
            // labelDName
            // 
            this.labelDName.AutoSize = true;
            this.labelDName.Location = new System.Drawing.Point(48, 119);
            this.labelDName.Name = "labelDName";
            this.labelDName.Size = new System.Drawing.Size(38, 13);
            this.labelDName.TabIndex = 20;
            this.labelDName.Text = "Name:";
            // 
            // labelDProgress
            // 
            this.labelDProgress.AutoSize = true;
            this.labelDProgress.Location = new System.Drawing.Point(48, 132);
            this.labelDProgress.Name = "labelDProgress";
            this.labelDProgress.Size = new System.Drawing.Size(51, 13);
            this.labelDProgress.TabIndex = 21;
            this.labelDProgress.Text = "Progress:";
            // 
            // labelDStatus
            // 
            this.labelDStatus.AutoSize = true;
            this.labelDStatus.Location = new System.Drawing.Point(48, 145);
            this.labelDStatus.Name = "labelDStatus";
            this.labelDStatus.Size = new System.Drawing.Size(40, 13);
            this.labelDStatus.TabIndex = 22;
            this.labelDStatus.Text = "Status:";
            // 
            // labelInfoRes
            // 
            this.labelInfoRes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelInfoRes.AutoSize = true;
            this.labelInfoRes.Location = new System.Drawing.Point(476, 198);
            this.labelInfoRes.Name = "labelInfoRes";
            this.labelInfoRes.Size = new System.Drawing.Size(38, 13);
            this.labelInfoRes.TabIndex = 23;
            this.labelInfoRes.Text = "0 Res:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "Current download:";
            // 
            // labelDChunk
            // 
            this.labelDChunk.AutoSize = true;
            this.labelDChunk.Location = new System.Drawing.Point(48, 158);
            this.labelDChunk.Name = "labelDChunk";
            this.labelDChunk.Size = new System.Drawing.Size(61, 13);
            this.labelDChunk.TabIndex = 26;
            this.labelDChunk.Text = "ChunkSize:";
            // 
            // labelDRetries
            // 
            this.labelDRetries.AutoSize = true;
            this.labelDRetries.Location = new System.Drawing.Point(48, 171);
            this.labelDRetries.Name = "labelDRetries";
            this.labelDRetries.Size = new System.Drawing.Size(43, 13);
            this.labelDRetries.TabIndex = 27;
            this.labelDRetries.Text = "Retries:";
            // 
            // labelRequests
            // 
            this.labelRequests.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelRequests.AutoSize = true;
            this.labelRequests.Location = new System.Drawing.Point(476, 211);
            this.labelRequests.Name = "labelRequests";
            this.labelRequests.Size = new System.Drawing.Size(64, 13);
            this.labelRequests.TabIndex = 30;
            this.labelRequests.Text = "0 Requests.";
            // 
            // labelUploads
            // 
            this.labelUploads.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelUploads.AutoSize = true;
            this.labelUploads.Location = new System.Drawing.Point(476, 224);
            this.labelUploads.Name = "labelUploads";
            this.labelUploads.Size = new System.Drawing.Size(58, 13);
            this.labelUploads.TabIndex = 31;
            this.labelUploads.Text = "0 Uploads.";
            // 
            // textBoxRemoteIP
            // 
            this.textBoxRemoteIP.Location = new System.Drawing.Point(164, 47);
            this.textBoxRemoteIP.Name = "textBoxRemoteIP";
            this.textBoxRemoteIP.Size = new System.Drawing.Size(120, 20);
            this.textBoxRemoteIP.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(122, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 33;
            this.label5.Text = "Rem.IP";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(287, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 34;
            this.label6.Text = "Current upload:";
            // 
            // labelUName
            // 
            this.labelUName.AutoSize = true;
            this.labelUName.Location = new System.Drawing.Point(297, 119);
            this.labelUName.Name = "labelUName";
            this.labelUName.Size = new System.Drawing.Size(38, 13);
            this.labelUName.TabIndex = 35;
            this.labelUName.Text = "Name:";
            // 
            // labelUProgress
            // 
            this.labelUProgress.AutoSize = true;
            this.labelUProgress.Location = new System.Drawing.Point(297, 132);
            this.labelUProgress.Name = "labelUProgress";
            this.labelUProgress.Size = new System.Drawing.Size(51, 13);
            this.labelUProgress.TabIndex = 36;
            this.labelUProgress.Text = "Progress:";
            // 
            // labelUStatus
            // 
            this.labelUStatus.AutoSize = true;
            this.labelUStatus.Location = new System.Drawing.Point(297, 145);
            this.labelUStatus.Name = "labelUStatus";
            this.labelUStatus.Size = new System.Drawing.Size(40, 13);
            this.labelUStatus.TabIndex = 37;
            this.labelUStatus.Text = "Status:";
            // 
            // labelUChunk
            // 
            this.labelUChunk.AutoSize = true;
            this.labelUChunk.Location = new System.Drawing.Point(297, 158);
            this.labelUChunk.Name = "labelUChunk";
            this.labelUChunk.Size = new System.Drawing.Size(61, 13);
            this.labelUChunk.TabIndex = 38;
            this.labelUChunk.Text = "ChunkSize:";
            // 
            // buttonBroadcast
            // 
            this.buttonBroadcast.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonBroadcast.Location = new System.Drawing.Point(476, 72);
            this.buttonBroadcast.Name = "buttonBroadcast";
            this.buttonBroadcast.Size = new System.Drawing.Size(75, 23);
            this.buttonBroadcast.TabIndex = 39;
            this.buttonBroadcast.Text = "Broadcast";
            this.buttonBroadcast.UseVisualStyleBackColor = true;
            this.buttonBroadcast.Click += new System.EventHandler(this.ButtonBroadcast_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.buttonChunkSize);
            this.groupBox2.Controls.Add(this.labelChunkSize);
            this.groupBox2.Controls.Add(this.textBoxChunkSize);
            this.groupBox2.Controls.Add(this.buttonBroadcast);
            this.groupBox2.Controls.Add(this.labelUChunk);
            this.groupBox2.Controls.Add(this.labelUStatus);
            this.groupBox2.Controls.Add(this.labelUProgress);
            this.groupBox2.Controls.Add(this.labelUName);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.textBoxRemoteIP);
            this.groupBox2.Controls.Add(this.labelUploads);
            this.groupBox2.Controls.Add(this.labelRequests);
            this.groupBox2.Controls.Add(this.labelDRetries);
            this.groupBox2.Controls.Add(this.labelDChunk);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.labelInfoRes);
            this.groupBox2.Controls.Add(this.labelDStatus);
            this.groupBox2.Controls.Add(this.labelDProgress);
            this.groupBox2.Controls.Add(this.labelDName);
            this.groupBox2.Controls.Add(this.checkBoxEnabled);
            this.groupBox2.Controls.Add(this.buttonResetList);
            this.groupBox2.Controls.Add(this.textBoxName);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.comboBoxDevices);
            this.groupBox2.Controls.Add(this.buttonDisconnect);
            this.groupBox2.Controls.Add(this.buttonClearView);
            this.groupBox2.Controls.Add(this.textBoxView);
            this.groupBox2.Controls.Add(this.buttonUpload);
            this.groupBox2.Controls.Add(this.buttonDownload);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.textBoxFile);
            this.groupBox2.Controls.Add(this.buttonDiscover);
            this.groupBox2.Controls.Add(this.buttonFtsOpen);
            this.groupBox2.Controls.Add(this.textBoxFtsPort);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(560, 437);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "FTS";
            // 
            // buttonChunkSize
            // 
            this.buttonChunkSize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonChunkSize.Location = new System.Drawing.Point(454, 408);
            this.buttonChunkSize.Name = "buttonChunkSize";
            this.buttonChunkSize.Size = new System.Drawing.Size(100, 23);
            this.buttonChunkSize.TabIndex = 42;
            this.buttonChunkSize.Text = "Apply Chunk Size";
            this.buttonChunkSize.UseVisualStyleBackColor = true;
            this.buttonChunkSize.Click += new System.EventHandler(this.buttonChunkSize_Click);
            // 
            // labelChunkSize
            // 
            this.labelChunkSize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelChunkSize.AutoSize = true;
            this.labelChunkSize.Location = new System.Drawing.Point(10, 413);
            this.labelChunkSize.Name = "labelChunkSize";
            this.labelChunkSize.Size = new System.Drawing.Size(321, 13);
            this.labelChunkSize.TabIndex = 41;
            this.labelChunkSize.Text = "ChunkSize (*If discover but no transfer on internet, try MTU: 1400):";
            // 
            // textBoxChunkSize
            // 
            this.textBoxChunkSize.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxChunkSize.Location = new System.Drawing.Point(336, 410);
            this.textBoxChunkSize.MaxLength = 5;
            this.textBoxChunkSize.Name = "textBoxChunkSize";
            this.textBoxChunkSize.Size = new System.Drawing.Size(112, 20);
            this.textBoxChunkSize.TabIndex = 40;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 461);
            this.Controls.Add(this.groupBox2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(600, 500);
            this.Name = "Form1";
            this.Text = "File Transfer Server";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxFtsPort;
        private System.Windows.Forms.Button buttonFtsOpen;
        private System.Windows.Forms.Button buttonDiscover;
        private System.Windows.Forms.TextBox textBoxFile;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonDownload;
        private System.Windows.Forms.Button buttonUpload;
        private System.Windows.Forms.TextBox textBoxView;
        private System.Windows.Forms.Button buttonClearView;
        private System.Windows.Forms.Button buttonDisconnect;
        private System.Windows.Forms.ComboBox comboBoxDevices;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Button buttonResetList;
        private System.Windows.Forms.CheckBox checkBoxEnabled;
        private System.Windows.Forms.Label labelDName;
        private System.Windows.Forms.Label labelDProgress;
        private System.Windows.Forms.Label labelDStatus;
        private System.Windows.Forms.Label labelInfoRes;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelDChunk;
        private System.Windows.Forms.Label labelDRetries;
        private System.Windows.Forms.Label labelRequests;
        private System.Windows.Forms.Label labelUploads;
        private System.Windows.Forms.TextBox textBoxRemoteIP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelUName;
        private System.Windows.Forms.Label labelUProgress;
        private System.Windows.Forms.Label labelUStatus;
        private System.Windows.Forms.Label labelUChunk;
        private System.Windows.Forms.Button buttonBroadcast;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonChunkSize;
        private System.Windows.Forms.Label labelChunkSize;
        private System.Windows.Forms.TextBox textBoxChunkSize;
    }
}

