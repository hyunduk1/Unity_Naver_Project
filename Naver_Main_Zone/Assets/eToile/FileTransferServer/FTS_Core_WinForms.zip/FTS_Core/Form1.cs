﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace FTS_Core
{
    public partial class Form1 : Form
    {
        delegate void EventString(string text); // Event delegate with a string as argument.
        FTSCore _fts;                           // The FileTransferServer.
        FTSCore.FileRequest _fileRequest;       // Current file request.
        FTSCore.FileUpload _fileUpload;         // Current file upload;

        public Form1()
        {
            InitializeComponent();
        }

        void Form1_Load(object sender, EventArgs e)
        {
            _fts = new FTSCore(FileManagement.CustomParser<int>(textBoxFtsPort.Text), ErrorEvent, UpdateDevicesList, DownloadEvent, NotFoundEvent, ForcedDownloadEvent, TimeoutDownloadEvent, UploadBeginEvent, UploadEvent, TimeoutUploadEvent);
            // Default values:
            textBoxName.Text = _fts._deviceName;
            checkBoxEnabled.Checked = _fts._serverEnabled;
            textBoxChunkSize.Text = _fts._chunkSize.ToString();

            AddText("Connected to port: " + textBoxFtsPort.Text);
            AddText("Local IP main: " + _fts.GetIP());
            AddText("Local IP secn: " + _fts.GetIP(true));
            AddText("Chunk size: " + _fts._chunkSize.ToString());
        }

        /*******************
         * FTS UI controls *
         *******************/
        // Set the name of the device:
        void TextBoxName_TextChanged(object sender, EventArgs e)
        {
            if(_fts != null)
                _fts._deviceName = textBoxName.Text;
        }
        // Set the server capabilities:
        void CheckBoxEnabled_CheckedChanged(object sender, EventArgs e)
        {
            if(_fts != null)
                _fts._serverEnabled = checkBoxEnabled.Checked;
        }
        // Connect and disconnect the server:
        void ButtonFtsOpen_Click(object sender, EventArgs e)
        {
            if(_fts == null)
            {
                _fts = new FTSCore(FileManagement.CustomParser<int>(textBoxFtsPort.Text), ErrorEvent, UpdateDevicesList, DownloadEvent, NotFoundEvent, ForcedDownloadEvent, TimeoutDownloadEvent, UploadEvent, TimeoutUploadEvent);
                _fts._deviceName = textBoxName.Text;
                _fts._serverEnabled = checkBoxEnabled.Checked;
                AddText("Connected to port: " + textBoxFtsPort.Text);
                AddText("Local IP main: " + _fts.GetIP());
                AddText("Local IP secn: " + _fts.GetIP(true));
            }
        }
        void ButtonDisconnect_Click(object sender, EventArgs e)
        {
            if(_fts != null)
            {
                _fts.Dispose();
                _fts = null;
                AddText("Disposed");
            }
        }

        // Send the auto-discover command:
        void ButtonDiscover_Click(object sender, EventArgs e)
        {
            if (_fts != null)
            {
                _fts.SendPollRequest(textBoxRemoteIP.Text);
            }
        }
        // Clear the list of detected devices:
        void ButtonResetList_Click(object sender, EventArgs e)
        {
            if(_fts != null)
            {
                _fts.ResetDeviceList();
                UpdateDevicesList(_fts._devices);
            }
        }

        // Request a download:
        void ButtonDownload_Click(object sender, EventArgs e)
        {
            if(_fts != null && comboBoxDevices.SelectedIndex >= 0)
            {
                _fileRequest = _fts.RequestFile(comboBoxDevices.SelectedIndex, textBoxFile.Text);
                AddText("Download requested: " + textBoxFile.Text);
            }
        }
        // Request an upload:
        void ButtonUpload_Click(object sender, EventArgs e)
        {
            if (_fts != null && comboBoxDevices.SelectedIndex >= 0)
            {
                _fileUpload = _fts.SendFile(comboBoxDevices.SelectedIndex, textBoxFile.Text);
                if(_fileUpload != null)
                    AddText("Upload requested: " + textBoxFile.Text);
                else
                    AddText("Upload not found: " + textBoxFile.Text);
            }
        }
        // Request upload in broadcast:
        void ButtonBroadcast_Click(object sender, EventArgs e)
        {
            if (_fts != null)
            {
                _fts.BroadcastFile(textBoxFile.Text);
            }
        }

        // Thread safe text update (multi-threading):
        void AddText(string text)
        {
            if (textBoxView.InvokeRequired)
            {
                EventString d = new EventString(AddText);
                Invoke(d, new object[] { text });
            }
            else
            {
                if (!textBoxView.IsDisposed)
                    textBoxView.AppendText(text + Environment.NewLine);
            }
        }
        // Clear the text window:
        void ButtonClearView_Click(object sender, EventArgs e)
        {
            textBoxView.Clear();
        }

        // Download status UI update:
        void Timer1_Tick(object sender, EventArgs e)
        {
            // Resources:
            if(_fts != null)
            {
                labelInfoRes.Text = _fts.GetResourcesCount().ToString() + " Res: " + Math.Round(_fts.GetResourcesSize() / 1048576f, 1).ToString() + "MB";
                labelRequests.Text = _fts.RequestCount().ToString() + " Requests.";
                labelUploads.Text = _fts.UploadCount().ToString() + " Uploads.";
            }
            // Current download:
            if (_fileRequest != null)
            {
                labelDName.Text = "Name: " + _fileRequest._sourceName;
                labelDProgress.Text = "Progress: " + (_fileRequest.GetProgress() * 100f).ToString("0") + "%";
                labelDStatus.Text = "Status: " + _fileRequest.GetStatus().ToString();
                labelDChunk.Text = "ChunkSize: " + _fileRequest._chunkSize.ToString();
                labelDRetries.Text = "Retries: " + _fileRequest._retries.ToString();
            }
            // Current upload:
            if (_fileUpload != null)
            {
                labelUName.Text = "Name: " + _fileUpload.GetName();
                labelUProgress.Text = "Progress: " + (_fileUpload.GetProgress() * 100f).ToString("0") + "%";
                labelUStatus.Text = "Status: " + _fileUpload.GetStatus().ToString();
                labelUChunk.Text = "ChunkSize: " + _fileUpload._chunkSize;
            }

        }

        /***********
         * Events: *
         ***********/
        // Update the devices list:
        void UpdateDevicesList(List<FTSCore.RemoteDevice> devices)
        {
            if (comboBoxDevices.InvokeRequired)
            {
                FTSCore.EventDevices d = new FTSCore.EventDevices(UpdateDevicesList);
                Invoke(d, new object[] { devices });
            }
            else
            {
                if (!comboBoxDevices.IsDisposed)
                {
                    comboBoxDevices.Items.Clear();                                  // Clear the list.
                    comboBoxDevices.Text = "";
                    for (int i = 0; i < devices.Count; i++)                          // Add all detected devices.
                    {
                        comboBoxDevices.Items.Add(devices[i].name + " [" + devices[i].isServer.ToString() + "]");
                    }
                    if (comboBoxDevices.Items.Count > 0)
                        comboBoxDevices.SelectedItem = comboBoxDevices.Items[0];    // Select the first one by default.
                }
            }
        }
        // Error event:
        void ErrorEvent(int code, string message)
        {
            AddText("[Error " + code.ToString() + "] " + message);
        }
        
        // A file has been downloaded:
        void DownloadEvent(FTSCore.FileRequest fileData)
        {
            AddText("Downloaded: " + fileData._saveName + " - T: " + fileData._elapsedTime.ToString() + "s - TR: " + fileData._transferRate.ToString() + "MBs - R: " + fileData._retries.ToString());
        }
        // The requested file wasn't found in server side:
        void NotFoundEvent(FTSCore.FileRequest fileData)
        {
            AddText("File not found: " + fileData._saveName);
        }
        // A file is being received without being requested:
        void ForcedDownloadEvent(FTSCore.FileRequest fileData)
        {
            _fileRequest = fileData;
            AddText("Download started: " + _fileRequest._sourceName);
        }
        // Timeout event:
        void TimeoutDownloadEvent(FTSCore.FileRequest fileData)
        {
            AddText("[Timeout download] " + fileData._sourceName);
        }

        // Upload has begun:
        void UploadBeginEvent(FTSCore.FileUpload upload)
        {
            _fileUpload = upload;
            AddText("Upload started: " + upload.GetName() + " - Status:" + upload.GetStatus().ToString());
        }
        // Upload event:
        void UploadEvent(FTSCore.FileUpload upload)
        {
            AddText("Uploaded: " + upload.GetName() + " - Status:" + upload.GetStatus().ToString());
        }
        // Upload timeout event:
        void TimeoutUploadEvent(FTSCore.FileUpload upload)
        {
            AddText("[Timeout upload] " + upload.GetName());
        }

        private void buttonChunkSize_Click(object sender, EventArgs e)
        {
            _fts._chunkSize = FileManagement.CustomParser<int>(textBoxChunkSize.Text);
            AddText("Chunk size: " + _fts._chunkSize.ToString());
        }
    }
}
