This application was built in Visual Studio.

The "Shared" and "Downloads" folders are in:
"Documents/FTS_Core/"
(These folders are created automatically at runtime)

Copy the example content of "FTSShared" into your own "FTSShared" to test transferences with Unity test builds.

Javier (eToile)