﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SocketsUnderControl
{
    public partial class Form1 : Form
    {
        delegate void EventString(string text);                         // Event delegate with a string as argument.
        delegate void EventTcpConnection(TCPConnection text);           // Event delegate with a object as argument.
        delegate void EventWsConnection(WSConnection text);             // Event delegate with a object as argument.

        // Connections:
        UDPConnection _udp;
        TCPConnection _tcp;
        TCPServer _tcpServer;
        WSConnection _ws;
        WSServer _wsServer;

        // Constructor:
        public Form1()
        {
            InitializeComponent();
        }

        // Set all the objects:
        void Form1_Load(object sender, EventArgs e)
        {
            Text = "Sockets Under Control V1.4";
            // Get the default IP address:
            _udp = new UDPConnection(int.Parse(textBoxRxPortUdp.Text), textBoxRxIPUdp.Text, OnOpenUdp, OnMessageUdp, OnErrorUdp, OnCloseUdp);
            string defaultAddress = _udp.GetDefaultIPAddress();
            if (defaultAddress.Contains(":"))
                defaultAddress = "[" + defaultAddress + "]";        // In case it's IPV6.
            // TCP default target:
            textBoxTxIPTcp.Text = defaultAddress;
            // WS default target:
            textBoxTxUrlWS.Text = "http://"+ defaultAddress + ":60003/ws/";
            // WSS default URL:
            textBoxRxIPWsServer.Text = "http://" + defaultAddress + ":60003/ws/";
            // NTP:
            textBoxNTPServerUrl.Text = "time.windows.com";
            textBoxNTPServerPort.Text = "123";
            progressBarTime.Value = 0;
            textBoxWSRAddress.Text = "http://" + defaultAddress + ":60012/ntp/";
            NTP_RealTime.onError = (int code, string message) => {
                ShowAlert("NTP error (" + code + "): " + System.Environment.NewLine + message);
            };
            // All connection are created at start, then the application just connects or disconnects them:
            _tcp = new TCPConnection(textBoxRxIPTcp.Text, OnOpenTcp, OnMessageTcp, OnErrorTcp, OnCloseTcp);
            _tcpServer = new TCPServer(int.Parse(textBoxRxPortTcpServer.Text), textBoxRxIPTcpServer.Text, OnOpenTcpServer, OnNewConnectionTcpServer, OnErrorTcpServer, OnCloseTcpServer);
            _ws = new WSConnection(OnOpenWS, OnMessageWS, OnErrorWS, OnCloseWS);
            _wsServer = new WSServer(textBoxRxIPWsServer.Text, OnOpenWsServer, OnNewConnectionWsServer, OnErrorWsServer, OnCloseWsServer);
        }
        // Disconnect and destroy all the connections:
        void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_tcpServer != null)
            {
                _tcpServer.Dispose();
                _tcpServer = null;
            }
            if (_tcp != null)
            {
                _tcp.Dispose();
                _tcp = null;
            }
            if (_udp != null)
            {
                _udp.Dispose();
                _udp = null;
            }
            if (_wsServer != null)
            {
                _wsServer.Dispose();
                _wsServer = null;
            }
            if (_ws != null)
            {
                _ws.Dispose();
                _ws = null;
            }
            NTP_RealTime.Dispose();
        }
        /// <summary>Presentar un aviso al usuario (aceptar para continuar)</summary>
        public void ShowAlert(string message)
        {
            BeginInvoke(new MethodInvoker(delegate
            {
                MessageBox.Show(this, message);
            }));
        }

        /*******************
         * UDP tab control *
         *******************/
        // To add text safely (multi-threading):
        void AddTextUdp(string text)
        {
            if (!Disposing && !IsDisposed && textBoxViewUdp.InvokeRequired)
            {
                EventString d = new EventString(AddTextUdp);
                Invoke(d, new object[] { text });
            }
            else
            {
                if (!textBoxViewUdp.IsDisposed)
                    textBoxViewUdp.AppendText(text + Environment.NewLine);
            }
        }
        // UI events:
        void ButtonClearViewUdp_Click(object sender, EventArgs e)
        {
            textBoxViewUdp.Clear();
        }
        void ButtonSetupUdp_Click(object sender, EventArgs e)
        {
            _udp.Setup(int.Parse(textBoxRxPortUdp.Text), textBoxRxIPUdp.Text, OnOpenUdp, OnMessageUdp, OnErrorUdp, OnCloseUdp);
            AddTextUdp("LocalIP: " + _udp.GetIP());
            AddTextUdp("LocalAuxIP: " + _udp.GetIP(true));
            if (textBoxTxIPUdp.Text == "")
                textBoxTxIPUdp.Text = _udp.IPV4BroadcastAddress();
        }
        void ButtonOpenUdp_Click(object sender, EventArgs e)
        {
            if(!_udp.IsConnected())
                _udp.Connect(int.Parse(textBoxRxPortUdp.Text), "", 60f);
        }
        void ButtonCloseUdp_Click(object sender, EventArgs e)
        {
            _udp.Disconnect();
            AddTextUdp("Closed by user.");
        }
        void ButtonSendUdp_Click(object sender, EventArgs e)
        {
            _udp.SendData(textBoxTxIPUdp.Text, textBoxMsgUdp.Text, int.Parse(textBoxTxPortUdp.Text));
            AddTextUdp("[out] " + textBoxMsgUdp.Text);
        }
        void ButtonSendBroadcast_Click(object sender, EventArgs e)
        {
            _udp.SendData(_udp.IPV4BroadcastAddress(), textBoxMsgUdp.Text, int.Parse(textBoxRxPortUdp.Text));
            AddTextUdp("[out] " + textBoxMsgUdp.Text);
        }
        void ButtonBuffer_Click(object sender, EventArgs e)
        {
            AddTextUdp("Buffer: " + _udp.GetIOBufferSize().ToString());
        }
        void ButtonGetIPUdp_Click(object sender, EventArgs e)
        {
            AddTextUdp("LocalIP: " + _udp.GetIP());
        }
        void ButtonGetAuxIPUdp_Click(object sender, EventArgs e)
        {
            AddTextUdp("LocalAuxIP: " + _udp.GetIP(true));
        }
        void ButtonIsOn_Click(object sender, EventArgs e)
        {
            AddTextUdp("Connected: " + _udp.IsConnected().ToString());
        }
        // UDP events:
        void OnOpenUdp(UDPConnection connection)
        {
            AddTextUdp("Connected as: " + _udp.GetIP() + " : " + _udp.GetPort());
            AddTextUdp("Connected as: " + _udp.GetIP(true) + " : " + _udp.GetPort());
        }
        void OnMessageUdp(byte[] message, string remoteIP, UDPConnection connection)
        {
            // Get the content up to char 35 (#):
            int msgLen = 0;
            for (int i = 0; i < message.Length; i++)
            {
                if (message[i] == '#')
                {
                    msgLen = i;         // '#' is excluded.
                    break;
                }
            }
            if (msgLen > 0)
            {
                // Stress test protocol:
                byte[] msg = new byte[msgLen];
                System.Buffer.BlockCopy(message, 0, msg, 0, msgLen);
                string[] fields = connection.ByteArrayToString(msg).Split(';');
                switch (fields[0])
                {
                    case "PING":
                        // Send the PONG message back to remoteIP:
                        string pong = "PONG;" + fields[1] + ";" + fields[2] + ";" + NTP_RealTime.GetUTCTime().TimeOfDay.TotalMilliseconds + "#";
                        connection.SendData(remoteIP, pong);
                        break;
                }
            }
            else
            {
                // Shows received messages on top of the screen and disappears automatically after 10 seconds:
                AddTextUdp("[in] (" + remoteIP + ") " + _udp.ByteArrayToString(message));
            }
        }
        void OnCloseUdp(UDPConnection connection)
        {
            AddTextUdp("Closed");
        }
        void OnErrorUdp(int errorCode, string message, UDPConnection connection)
        {
            AddTextUdp("[error] (" + errorCode + "): " + message);
        }

        /*******************
         * TCP tab control *
         *******************/
        // To add text safely (multi-threading):
        void AddTextTcp(string text)
        {
            if (!Disposing && !IsDisposed && textBoxViewTcp.InvokeRequired)
            {
                EventString d = new EventString(AddTextTcp);
                Invoke(d, new object[] { text });
            }
            else
            {
                if (!textBoxViewTcp.IsDisposed)
                    textBoxViewTcp.AppendText(text + Environment.NewLine);
            }
        }
        // UI events:
        void ButtonClearViewTcp_Click(object sender, EventArgs e)
        {
            textBoxViewTcp.Clear();
        }
        void ButtonSetupTcp_Click(object sender, EventArgs e)
        {
            _tcp.Setup(textBoxRxIPTcp.Text, OnOpenTcp, OnMessageTcp, OnErrorTcp, OnCloseTcp);
            AddTextTcp("Setup");
        }
        void ButtonOpenTcp_Click(object sender, EventArgs e)
        {
            if(!_tcp.IsConnected())
                _tcp.Connect(FileManagement.CustomParser<int>(textBoxTxPortTcp.Text), textBoxTxIPTcp.Text);
        }
        void ButtonCloseTcp_Click(object sender, EventArgs e)
        {
            _tcp.Disconnect();
            AddTextTcp("Closed by user.");
        }
        void ButtonSendTcp_Click(object sender, EventArgs e)
        {
            _tcp.SendData(_tcp.StringToByteArray(textBoxMsgTcp.Text));
            AddTextTcp("[out] " + textBoxMsgTcp.Text);
        }             
        void ButtonGetIPTcp_Click(object sender, EventArgs e)
        {
            AddTextTcp("LocalIP: " + _tcp.GetIP());
        }
        void ButtonIsListeningTcp_Click(object sender, EventArgs e)
        {
            AddTextTcp("Listening: " + _tcp.IsConnected().ToString());
        }
        // TCP events:
        void OnOpenTcp(TCPConnection connection)
        {
            AddTextTcp("Connected as: " + _tcp.GetIP() + " : " + _tcp.GetPort());
        }
        void OnMessageTcp(byte[] message, TCPConnection connection)
        {
            AddTextTcp("[in] (" + connection.GetIP() + ") " + _tcp.ByteArrayToString(message));
        }
        void OnCloseTcp(TCPConnection connection)
        {
            AddTextTcp("Closed");
        }
        void OnErrorTcp(int errorCode, string message, TCPConnection connection)
        {
            AddTextTcp("[error] (" + errorCode + "): " + message);
        }

        /**************************
         * TCP server tab control *
         **************************/
        // To add text safely (multi-threading):
        void AddTextTcpServer(string text)
        {
            if (!Disposing && !IsDisposed && textBoxViewTcpServer.InvokeRequired)
            {
                EventString d = new EventString(AddTextTcpServer);
                Invoke(d, new object[] { text });
            }
            else
            {
                if (!textBoxViewTcpServer.IsDisposed)
                    textBoxViewTcpServer.AppendText(text + Environment.NewLine);
            }
        }
        void SetLabelTcpServer(string text)
        {
            if (!Disposing && !IsDisposed && labelConnectionsTcp.InvokeRequired)
            {
                EventString d = new EventString(SetLabelTcpServer);
                Invoke(d, new object[] { text });
            }
            else
            {
                if (!labelConnectionsTcp.IsDisposed)
                    labelConnectionsTcp.Text = text;
            }
        }
        // UI events:
        void ButtonClearViewTcpServer_Click(object sender, EventArgs e)
        {
            textBoxViewTcpServer.Clear();
        }
        void ButtonSetupTcpServer_Click(object sender, EventArgs e)
        {
            _tcpServer.Setup(int.Parse(textBoxRxPortTcpServer.Text), textBoxRxIPTcpServer.Text, OnOpenTcpServer, OnNewConnectionTcpServer, OnErrorTcpServer, OnCloseTcpServer);
            AddTextTcpServer("LocalIP: " + _tcpServer.GetIP());
            AddTextTcpServer("LocalAuxIP: " + _tcpServer.GetIP(true));
        }
        void ButtonStartTcpServer_Click(object sender, EventArgs e)
        {
            if (!_tcpServer.IsConnected())
                _tcpServer.Connect();
        }
        void ButtonCloseTcpServer_Click(object sender, EventArgs e)
        {
            _tcpServer.Disconnect();
            SetLabelTcpServer("Connections: 0");
            AddTextTcpServer("Closed by user.");
        }
        void ButtonSendBroadcastTcpServer_Click(object sender, EventArgs e)
        {
            if (_tcpServer.IsConnected())
            {
                _tcpServer.Distribute(textBoxMsgTcpServer.Text);
                AddTextTcpServer("[out] " + textBoxMsgTcpServer.Text);
            }
        }
        void ButtonGetIPTcpServer_Click(object sender, EventArgs e)
        {
            AddTextTcpServer("LocalIP: " + _tcpServer.GetIP());
        }
        void ButtonGetAuxIPTcpServer_Click(object sender, EventArgs e)
        {
            AddTextTcpServer("LocalAuxIP: " + _tcpServer.GetIP(true));
        }
        void ButtonIsListeningTcpServer_Click(object sender, EventArgs e)
        {
            AddTextTcpServer("Listening: " + _tcpServer.IsConnected().ToString());
        }
        // TCP server events:
        void OnOpenTcpServer(TCPServer server)
        {
            SetLabelTcpServer("Connections: 0");
            AddTextTcpServer("Started as: " + server.GetIP() + " : " + server.GetPort());
            AddTextTcpServer("Started as: " + server.GetIP(true) + " : " + server.GetPort());
        }
        void OnNewConnectionTcpServer(TCPConnection connection, TCPServer server)
        {
            connection.onMessage = OnMessageTcpConnection;
            connection.onClose = OnCloseTcpConnection;
            connection.onError = OnErrorTcpConnection;
            // Connection information:
            SetLabelTcpServer("Connections: " + server.GetConnectionsCount().ToString());
            AddTextTcpServer("[New TCPConnection] " + connection.GetRemoteIP() + " : " + connection.GetRemotePort());
        }
        void OnCloseTcpServer(TCPServer server)
        {
            SetLabelTcpServer("Connections: 0");
            AddTextTcpServer("Closed");
        }
        void OnErrorTcpServer(int errorCode, string message, TCPServer server)
        {
            AddTextTcpServer("[error server " + server.GetIP() + "] (" + errorCode + "): " + message);
        }
        // TCP server connections events:
        void OnMessageTcpConnection(byte[] message, TCPConnection connection)
        {
            // Get the content up to char 35 (#):
            int msgLen = 0;
            for (int i = 0; i < message.Length; i++)
            {
                if (message[i] == '#')
                {
                    msgLen = i;         // '#' is excluded.
                    break;
                }
            }
            if (msgLen > 0)
            {
                // Stress test protocol:
                byte[] msg = new byte[msgLen];
                System.Buffer.BlockCopy(message, 0, msg, 0, msgLen);
                string[] fields = connection.ByteArrayToString(msg).Split(';');
                switch (fields[0])
                {
                    case "PING":
                        // Send the PONG message back to remoteIP:
                        string pong = "PONG;" + fields[1] + ";" + fields[2] + ";" + NTP_RealTime.GetUTCTime().TimeOfDay.TotalMilliseconds + "#";
                        connection.SendData(pong);
                        break;
                }
            }
            else
            {
                AddTextTcpServer("[in] (" + connection.GetRemoteIP() + " : " + connection.GetRemotePort() + ") " + connection.ByteArrayToString(message));
                if (checkBoxTCPSEcho.Checked)
                    connection.SendData(message);
            }
        }
        void OnCloseTcpConnection(TCPConnection connection)
        {
            SetLabelTcpServer("Connections: " + _tcpServer.GetConnectionsCount().ToString());
            AddTextTcpServer("[TCPConnection.Close] " + connection.GetRemoteIP() + " : " + connection.GetRemotePort());
        }
        void OnErrorTcpConnection(int code, string message, TCPConnection connection)
        {
            AddTextTcpServer("[TCPConnection.Error " + code.ToString() + "] " + connection.GetRemoteIP() + " : " + connection.GetRemotePort() + " - " + message);
        }

        /******************
         * WS tab control *
         ******************/
        // To add text safely (multi-threading):
        void AddTextWS(string text)
        {
            if (!Disposing && !IsDisposed && textBoxViewWS.InvokeRequired)
            {
                EventString d = new EventString(AddTextWS);
                Invoke(d, new object[] { text });
            }
            else
            {
                if (!textBoxViewWS.IsDisposed)
                    textBoxViewWS.AppendText(text + Environment.NewLine);
            }
        }
        // UI events:
        void ButtonClearViewWS_Click(object sender, EventArgs e)
        {
            textBoxViewWS.Clear();
        }
        void ButtonSetupWS_Click(object sender, EventArgs e)
        {
            _ws.Setup(OnOpenWS, OnMessageWS, OnErrorWS, OnCloseWS);
            AddTextWS("Setup.");
        }
        void ButtonOpenWS_Click(object sender, EventArgs e)
        {
            if(!_ws.IsConnected())
                _ws.Connect(textBoxTxUrlWS.Text);
        }
        void ButtonCloseWS_Click(object sender, EventArgs e)
        {
            _ws.Disconnect();
            AddTextWS("Closed by user.");
        }
        void ButtonSendWS_Click(object sender, EventArgs e)
        {
            if(_ws.IsConnected())
            {
                _ws.SendData(textBoxMsgWS.Text);
                AddTextWS("[out] " + textBoxMsgWS.Text);
            }
        }
        void ButtonGetIPWS_Click(object sender, EventArgs e)
        {
            if(_ws.IsConnected())
                AddTextWS("Connected to: " + _ws.GetURL());
        }
        void ButtonIsListeningWS_Click(object sender, EventArgs e)
        {
            AddTextWS("Listening: " + _ws.IsConnected());
        }
        // WS events:
        void OnOpenWS(WSConnection connection)
        {
            AddTextWS("Connected to: " + _ws.GetURL());
        }
        void OnMessageWS(byte[] message, WSConnection connection)
        {
            AddTextWS("[in] " + _ws.ByteArrayToString(message));
        }
        void OnCloseWS(WSConnection connection)
        {
            AddTextWS("Closed");
        }
        void OnErrorWS(int errorCode, string message, WSConnection connection)
        {
            AddTextWS("[Error] (" + errorCode + "): " + message);
        }

        /*************************
         * WS server tab control *
         *************************/
        // To add text safely (multi-threading):
        void AddTextWsServer(string text)
        {
            if (!Disposing && !IsDisposed && textBoxViewWsServer.InvokeRequired)
            {
                EventString d = new EventString(AddTextWsServer);
                Invoke(d, new object[] { text });
            }
            else
            {
                if (!textBoxViewWsServer.IsDisposed)
                    textBoxViewWsServer.AppendText(text + Environment.NewLine);
            }
        }
        void SetLabelWsServer(string text)
        {
            if (!Disposing && !IsDisposed && labelConnectionsWs.InvokeRequired)
            {
                EventString d = new EventString(SetLabelWsServer);
                Invoke(d, new object[] { text });
            }
            else
            {
                if (!labelConnectionsWs.IsDisposed)
                    labelConnectionsWs.Text = text;
            }
        }
        // UI events:
        void ButtonClearViewWsServer_Click(object sender, EventArgs e)
        {
            textBoxViewWsServer.Clear();
        }
        void ButtonSetupWsServer_Click(object sender, EventArgs e)
        {
            _wsServer.Setup(textBoxRxIPWsServer.Text, OnOpenWsServer, OnNewConnectionWsServer, OnErrorWsServer, OnCloseWsServer);
            AddTextWsServer("Setup.");
        }
        void ButtonStartWsServer_Click(object sender, EventArgs e)
        {
            if (!_wsServer.IsConnected())
                _wsServer.Connect();
        }
        void ButtonCloseWsServer_Click(object sender, EventArgs e)
        {
            _wsServer.Disconnect();
            SetLabelWsServer("Connections: 0");
            AddTextWsServer("Closed by user.");
        }
        void ButtonSendBroadcastWSServer_Click(object sender, EventArgs e)
        {
            _wsServer.Distribute(textBoxMsgWSServer.Text);
            AddTextWsServer("[out] " + textBoxMsgWSServer.Text);
        }
        void buttonGetIPWsServer_Click(object sender, EventArgs e)
        {
            AddTextWsServer("LocalIP: " + _wsServer.GetIP());
            AddTextWsServer("LocalURL: " + _wsServer.GetURL());
        }
        void buttonGetAuxIPWsServer_Click(object sender, EventArgs e)
        {
            AddTextWsServer("LocalAuxIP: " + _wsServer.GetIP(true));
            AddTextWsServer("LocalAuxURL: " + _wsServer.GetURL(true));
        }
        void ButtonIsListeningWsServer_Click(object sender, EventArgs e)
        {
            AddTextWsServer("Listening: " + _wsServer.IsConnected().ToString());
        }
        // WS server events:
        void OnOpenWsServer(WSServer server)
        {
            SetLabelWsServer("Connections: 0");
            AddTextWsServer("Started.");
        }
        void OnNewConnectionWsServer(WSConnection connection, WSServer server)
        {
            // New connection received:
            SetLabelWsServer("Connections: " + _wsServer.GetConnectionsCount().ToString());
            AddTextWsServer("[New connection]");
            // Add connection events:
            connection.onMessage = OnMessageWsConnection;
            connection.onClose = OnCloseWsConnection;
            connection.onError = OnErrorWsConnection;
        }
        void OnCloseWsServer(WSServer server)
        {
            SetLabelWsServer("Connections: 0");
            AddTextWsServer("Closed");
        }
        void OnErrorWsServer(int errorCode, string message, WSServer server)
        {
            AddTextWsServer("[error] (" + errorCode + "): " + message);
        }
        // WS server connections events:
        void OnMessageWsConnection(byte[] message, WSConnection connection)
        {
            // Get the content up to char 35 (#):
            int msgLen = 0;
            for (int i = 0; i < message.Length; i++)
            {
                if (message[i] == '#')
                {
                    msgLen = i;         // '#' is excluded.
                    break;
                }
            }
            if (msgLen > 0)
            {
                // Stress test protocol:
                byte[] msg = new byte[msgLen];
                System.Buffer.BlockCopy(message, 0, msg, 0, msgLen);
                string[] fields = connection.ByteArrayToString(msg).Split(';');
                switch (fields[0])
                {
                    case "PING":
                        // Send the PONG message back to remoteIP:
                        string pong = "PONG;" + fields[1] + ";" + fields[2] + ";" + NTP_RealTime.GetUTCTime().TimeOfDay.TotalMilliseconds + "#";
                        connection.SendData(pong);
                        break;
                }
            }
            else
            {
                // Shows received messages on top of the screen and disappears automatically after 10 seconds:
                AddTextWsServer("[in] " + connection.ByteArrayToString(message));
                if (checkBoxWSSEcho.Checked)
                    connection.SendData(message);
            }
        }
        void OnCloseWsConnection(WSConnection connection)
        {
            SetLabelWsServer("Connections: " + _wsServer.GetConnectionsCount().ToString());
            AddTextWsServer("[Connection.Close]");
        }
        void OnErrorWsConnection(int code, string message, WSConnection connection)
        {
            AddTextWsServer("[Connection.Error " + code.ToString() + "] " + message);
        }

        /**************************
         * NTP server tab control *
         **************************/
        void timerNTPClient_Tick(object sender, EventArgs e)
        {
            DateTime _now = NTP_RealTime.GetUTCTime();
            if(NTP_RealTime._requestState == NTP_RealTime.RequestState.Ready)
                labelRealTime.Text = "Time: " + _now.ToLocalTime().ToString("HH:mm:ss.fff") + " - (" + NTP_RealTime._requestState.ToString() + ")";
            else
                labelRealTime.Text = "Time: " + _now.ToLocalTime().ToString("HH:mm:ss.fff") + " - (" + NTP_RealTime._requestState.ToString() + " " + NTP_RealTime._errorMsg + ")";
            progressBarTime.Value = (int)Math.Ceiling(100f * (_now.Millisecond / 1000f));
            if (progressBarTime.Value < 100)
            {
                // Workaroud to prevent progress bas smooth animation:
                progressBarTime.Value += 1;
                progressBarTime.Value -= 1;
            }
            // Status of all repeaters:
            if (NTP_RealTime._udpRepeater != null)
            {
                pictureBoxUDPR.BackColor = NTP_RealTime._udpRepeater.IsConnected() ? Color.Green : Color.Red;
                textBoxUDPRAddress.Text = NTP_RealTime._udpRepeater.GetIP();
            }
            if (NTP_RealTime._tcpRepeater != null)
            {
                pictureBoxTCPR.BackColor = NTP_RealTime._tcpRepeater.IsConnected() ? Color.Green : Color.Red;
                textBoxTCPRAddress.Text = NTP_RealTime._tcpRepeater.GetIP();
            }
            if (NTP_RealTime._wsRepeater != null)
            {
                pictureBoxWSR.BackColor = NTP_RealTime._wsRepeater.IsConnected() ? Color.Green : Color.Red;
                textBoxWSRAddress.Text = NTP_RealTime._wsRepeater.GetURL();
            }
        }

        // UI event for request synchronisation in real time:
        void buttonUDPRequest_Click(object sender, EventArgs e)
        {
            int port = string.IsNullOrEmpty(textBoxNTPServerPort.Text) ? 0 : int.Parse(textBoxNTPServerPort.Text);
            NTP_RealTime.SendUDPRequest(textBoxNTPServerUrl.Text, port);
        }
        void buttonTCPRequest_Click(object sender, EventArgs e)
        {
            NTP_RealTime.SendTCPRequest(textBoxNTPServerUrl.Text, int.Parse(textBoxNTPServerPort.Text));
        }
        void buttonWSRequest_Click(object sender, EventArgs e)
        {
            NTP_RealTime.SendWSRequest(textBoxNTPServerUrl.Text);
        }

        // UI events for UDP repeater:
        void buttonUDPRStart_Click(object sender, EventArgs e)
        {
            NTP_RealTime.StartUDPRepeater(int.Parse(textBoxUDPRPort.Text), textBoxUDPRAddress.Text, checkBoxUDPEmu.Checked);
        }
        void buttonUDPRstop_Click(object sender, EventArgs e)
        {
            NTP_RealTime.StopUDPRepeater();
            pictureBoxUDPR.BackColor = Color.Red;
        }

        // UI events for TCP repeater:
        void buttonTCPRStart_Click(object sender, EventArgs e)
        {
            NTP_RealTime.StartTCPRepeater(int.Parse(textBoxTCPRPort.Text), textBoxTCPRAddress.Text, checkBoxTCPEmu.Checked);
        }
        void buttonTCPRStop_Click(object sender, EventArgs e)
        {
            NTP_RealTime.StopTCPRepeater();
            pictureBoxTCPR.BackColor = Color.Red;
        }

        // UI events for WS repeater:
        void buttonWSRStart_Click(object sender, EventArgs e)
        {
            NTP_RealTime.StartWSRepeater(textBoxWSRAddress.Text, checkBoxWSEmu.Checked);
        }
        void buttonWSRStop_Click(object sender, EventArgs e)
        {
            NTP_RealTime.StopWSRepeater();
            pictureBoxWSR.BackColor = Color.Red;
        }
    }
}
