﻿namespace SocketsUnderControl
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.buttonGetAuxIPUdp = new System.Windows.Forms.Button();
            this.buttonIsListeningUdp = new System.Windows.Forms.Button();
            this.buttonSendBroadcastUdp = new System.Windows.Forms.Button();
            this.buttonGetIPUdp = new System.Windows.Forms.Button();
            this.textBoxTxIPUdp = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxTxPortUdp = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxRxIPUdp = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonBufferUdp = new System.Windows.Forms.Button();
            this.textBoxViewUdp = new System.Windows.Forms.TextBox();
            this.buttonSendUdp = new System.Windows.Forms.Button();
            this.buttonClearViewUdp = new System.Windows.Forms.Button();
            this.buttonCloseUdp = new System.Windows.Forms.Button();
            this.buttonOpenUdp = new System.Windows.Forms.Button();
            this.buttonSetupUdp = new System.Windows.Forms.Button();
            this.textBoxRxPortUdp = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxMsgUdp = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.buttonIsListeningTcp = new System.Windows.Forms.Button();
            this.buttonGetIPTcp = new System.Windows.Forms.Button();
            this.textBoxTxIPTcp = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxTxPortTcp = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxRxIPTcp = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxViewTcp = new System.Windows.Forms.TextBox();
            this.buttonSendTcp = new System.Windows.Forms.Button();
            this.buttonClearViewTcp = new System.Windows.Forms.Button();
            this.buttonCloseTcp = new System.Windows.Forms.Button();
            this.buttonOpenTcp = new System.Windows.Forms.Button();
            this.buttonSetupTcp = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxMsgTcp = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.checkBoxTCPSEcho = new System.Windows.Forms.CheckBox();
            this.buttonGetAuxIPTcpServer = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxMsgTcpServer = new System.Windows.Forms.TextBox();
            this.buttonSendBroadcastTcpServer = new System.Windows.Forms.Button();
            this.labelConnectionsTcp = new System.Windows.Forms.Label();
            this.buttonCloseTcpServer = new System.Windows.Forms.Button();
            this.textBoxViewTcpServer = new System.Windows.Forms.TextBox();
            this.buttonClearViewTcpServer = new System.Windows.Forms.Button();
            this.buttonIsListeningTcpServer = new System.Windows.Forms.Button();
            this.buttonGetIPTcpServer = new System.Windows.Forms.Button();
            this.textBoxRxIPTcpServer = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonStartTcpServer = new System.Windows.Forms.Button();
            this.buttonSetupTcpServer = new System.Windows.Forms.Button();
            this.textBoxRxPortTcpServer = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.buttonSetupWS = new System.Windows.Forms.Button();
            this.buttonIsListeningWS = new System.Windows.Forms.Button();
            this.buttonGetIPWS = new System.Windows.Forms.Button();
            this.textBoxTxUrlWS = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxViewWS = new System.Windows.Forms.TextBox();
            this.buttonSendWS = new System.Windows.Forms.Button();
            this.buttonClearViewWS = new System.Windows.Forms.Button();
            this.buttonCloseWS = new System.Windows.Forms.Button();
            this.buttonOpenWS = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.textBoxMsgWS = new System.Windows.Forms.TextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.buttonGetAuxIPWsServer = new System.Windows.Forms.Button();
            this.buttonGetIPWsServer = new System.Windows.Forms.Button();
            this.checkBoxWSSEcho = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxMsgWSServer = new System.Windows.Forms.TextBox();
            this.buttonSendBroadcastWSServer = new System.Windows.Forms.Button();
            this.labelConnectionsWs = new System.Windows.Forms.Label();
            this.buttonCloseWsServer = new System.Windows.Forms.Button();
            this.textBoxViewWsServer = new System.Windows.Forms.TextBox();
            this.buttonClearViewWsServer = new System.Windows.Forms.Button();
            this.buttonIsListeningWsServer = new System.Windows.Forms.Button();
            this.textBoxRxIPWsServer = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.buttonStartWsServer = new System.Windows.Forms.Button();
            this.buttonSetupWsServer = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBoxWSRepeater = new System.Windows.Forms.GroupBox();
            this.checkBoxWSEmu = new System.Windows.Forms.CheckBox();
            this.pictureBoxWSR = new System.Windows.Forms.PictureBox();
            this.buttonWSRStop = new System.Windows.Forms.Button();
            this.buttonWSRStart = new System.Windows.Forms.Button();
            this.labelWSRAddress = new System.Windows.Forms.Label();
            this.textBoxWSRAddress = new System.Windows.Forms.TextBox();
            this.groupBoxTCPRepeater = new System.Windows.Forms.GroupBox();
            this.checkBoxTCPEmu = new System.Windows.Forms.CheckBox();
            this.pictureBoxTCPR = new System.Windows.Forms.PictureBox();
            this.buttonTCPRStop = new System.Windows.Forms.Button();
            this.buttonTCPRStart = new System.Windows.Forms.Button();
            this.labelTCPRPort = new System.Windows.Forms.Label();
            this.labelTCPRAddress = new System.Windows.Forms.Label();
            this.textBoxTCPRPort = new System.Windows.Forms.TextBox();
            this.textBoxTCPRAddress = new System.Windows.Forms.TextBox();
            this.groupBoxUDPRepeater = new System.Windows.Forms.GroupBox();
            this.checkBoxUDPEmu = new System.Windows.Forms.CheckBox();
            this.pictureBoxUDPR = new System.Windows.Forms.PictureBox();
            this.buttonUDPRStop = new System.Windows.Forms.Button();
            this.buttonUDPRStart = new System.Windows.Forms.Button();
            this.labelUDPRPort = new System.Windows.Forms.Label();
            this.labelUDPRAddress = new System.Windows.Forms.Label();
            this.textBoxUDPRPort = new System.Windows.Forms.TextBox();
            this.textBoxUDPRAddress = new System.Windows.Forms.TextBox();
            this.labelRealTime = new System.Windows.Forms.Label();
            this.progressBarTime = new System.Windows.Forms.ProgressBar();
            this.buttonWSRequest = new System.Windows.Forms.Button();
            this.buttonTCPRequest = new System.Windows.Forms.Button();
            this.buttonUDPRequest = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxNTPServerPort = new System.Windows.Forms.TextBox();
            this.textBoxNTPServerUrl = new System.Windows.Forms.TextBox();
            this.timerNTPClient = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBoxWSRepeater.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWSR)).BeginInit();
            this.groupBoxTCPRepeater.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTCPR)).BeginInit();
            this.groupBoxUDPRepeater.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUDPR)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(461, 387);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tabPage1.Controls.Add(this.buttonGetAuxIPUdp);
            this.tabPage1.Controls.Add(this.buttonIsListeningUdp);
            this.tabPage1.Controls.Add(this.buttonSendBroadcastUdp);
            this.tabPage1.Controls.Add(this.buttonGetIPUdp);
            this.tabPage1.Controls.Add(this.textBoxTxIPUdp);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.textBoxTxPortUdp);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.textBoxRxIPUdp);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.buttonBufferUdp);
            this.tabPage1.Controls.Add(this.textBoxViewUdp);
            this.tabPage1.Controls.Add(this.buttonSendUdp);
            this.tabPage1.Controls.Add(this.buttonClearViewUdp);
            this.tabPage1.Controls.Add(this.buttonCloseUdp);
            this.tabPage1.Controls.Add(this.buttonOpenUdp);
            this.tabPage1.Controls.Add(this.buttonSetupUdp);
            this.tabPage1.Controls.Add(this.textBoxRxPortUdp);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.textBoxMsgUdp);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(453, 361);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "UDP";
            // 
            // buttonGetAuxIPUdp
            // 
            this.buttonGetAuxIPUdp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonGetAuxIPUdp.Location = new System.Drawing.Point(291, 62);
            this.buttonGetAuxIPUdp.Name = "buttonGetAuxIPUdp";
            this.buttonGetAuxIPUdp.Size = new System.Drawing.Size(75, 23);
            this.buttonGetAuxIPUdp.TabIndex = 20;
            this.buttonGetAuxIPUdp.Text = "Get aux IP";
            this.buttonGetAuxIPUdp.UseVisualStyleBackColor = true;
            this.buttonGetAuxIPUdp.Click += new System.EventHandler(this.ButtonGetAuxIPUdp_Click);
            // 
            // buttonIsListeningUdp
            // 
            this.buttonIsListeningUdp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonIsListeningUdp.Location = new System.Drawing.Point(372, 62);
            this.buttonIsListeningUdp.Name = "buttonIsListeningUdp";
            this.buttonIsListeningUdp.Size = new System.Drawing.Size(75, 23);
            this.buttonIsListeningUdp.TabIndex = 19;
            this.buttonIsListeningUdp.Text = "Connected";
            this.buttonIsListeningUdp.UseVisualStyleBackColor = true;
            this.buttonIsListeningUdp.Click += new System.EventHandler(this.ButtonIsOn_Click);
            // 
            // buttonSendBroadcastUdp
            // 
            this.buttonSendBroadcastUdp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSendBroadcastUdp.Location = new System.Drawing.Point(291, 119);
            this.buttonSendBroadcastUdp.Name = "buttonSendBroadcastUdp";
            this.buttonSendBroadcastUdp.Size = new System.Drawing.Size(75, 23);
            this.buttonSendBroadcastUdp.TabIndex = 18;
            this.buttonSendBroadcastUdp.Text = "Broadcast";
            this.buttonSendBroadcastUdp.UseVisualStyleBackColor = true;
            this.buttonSendBroadcastUdp.Click += new System.EventHandler(this.ButtonSendBroadcast_Click);
            // 
            // buttonGetIPUdp
            // 
            this.buttonGetIPUdp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonGetIPUdp.Location = new System.Drawing.Point(291, 33);
            this.buttonGetIPUdp.Name = "buttonGetIPUdp";
            this.buttonGetIPUdp.Size = new System.Drawing.Size(75, 23);
            this.buttonGetIPUdp.TabIndex = 17;
            this.buttonGetIPUdp.Text = "Get IP";
            this.buttonGetIPUdp.UseVisualStyleBackColor = true;
            this.buttonGetIPUdp.Click += new System.EventHandler(this.ButtonGetIPUdp_Click);
            // 
            // textBoxTxIPUdp
            // 
            this.textBoxTxIPUdp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxTxIPUdp.Location = new System.Drawing.Point(78, 121);
            this.textBoxTxIPUdp.Name = "textBoxTxIPUdp";
            this.textBoxTxIPUdp.Size = new System.Drawing.Size(207, 20);
            this.textBoxTxIPUdp.TabIndex = 16;
            this.textBoxTxIPUdp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Remote IP";
            // 
            // textBoxTxPortUdp
            // 
            this.textBoxTxPortUdp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxTxPortUdp.Location = new System.Drawing.Point(78, 93);
            this.textBoxTxPortUdp.Name = "textBoxTxPortUdp";
            this.textBoxTxPortUdp.Size = new System.Drawing.Size(207, 20);
            this.textBoxTxPortUdp.TabIndex = 14;
            this.textBoxTxPortUdp.Text = "60001";
            this.textBoxTxPortUdp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 93);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Remote Port";
            // 
            // textBoxRxIPUdp
            // 
            this.textBoxRxIPUdp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRxIPUdp.Location = new System.Drawing.Point(78, 35);
            this.textBoxRxIPUdp.Name = "textBoxRxIPUdp";
            this.textBoxRxIPUdp.Size = new System.Drawing.Size(207, 20);
            this.textBoxRxIPUdp.TabIndex = 12;
            this.textBoxRxIPUdp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(26, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Local IP";
            // 
            // buttonBufferUdp
            // 
            this.buttonBufferUdp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonBufferUdp.Location = new System.Drawing.Point(372, 91);
            this.buttonBufferUdp.Name = "buttonBufferUdp";
            this.buttonBufferUdp.Size = new System.Drawing.Size(75, 23);
            this.buttonBufferUdp.TabIndex = 10;
            this.buttonBufferUdp.Text = "Get buffer";
            this.buttonBufferUdp.UseVisualStyleBackColor = true;
            this.buttonBufferUdp.Click += new System.EventHandler(this.ButtonBuffer_Click);
            // 
            // textBoxViewUdp
            // 
            this.textBoxViewUdp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxViewUdp.Location = new System.Drawing.Point(6, 148);
            this.textBoxViewUdp.Multiline = true;
            this.textBoxViewUdp.Name = "textBoxViewUdp";
            this.textBoxViewUdp.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxViewUdp.Size = new System.Drawing.Size(441, 207);
            this.textBoxViewUdp.TabIndex = 9;
            // 
            // buttonSendUdp
            // 
            this.buttonSendUdp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSendUdp.Location = new System.Drawing.Point(291, 91);
            this.buttonSendUdp.Name = "buttonSendUdp";
            this.buttonSendUdp.Size = new System.Drawing.Size(75, 23);
            this.buttonSendUdp.TabIndex = 8;
            this.buttonSendUdp.Text = "Send";
            this.buttonSendUdp.UseVisualStyleBackColor = true;
            this.buttonSendUdp.Click += new System.EventHandler(this.ButtonSendUdp_Click);
            // 
            // buttonClearViewUdp
            // 
            this.buttonClearViewUdp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClearViewUdp.Location = new System.Drawing.Point(372, 119);
            this.buttonClearViewUdp.Name = "buttonClearViewUdp";
            this.buttonClearViewUdp.Size = new System.Drawing.Size(75, 23);
            this.buttonClearViewUdp.TabIndex = 7;
            this.buttonClearViewUdp.Text = "ClearView";
            this.buttonClearViewUdp.UseVisualStyleBackColor = true;
            this.buttonClearViewUdp.Click += new System.EventHandler(this.ButtonClearViewUdp_Click);
            // 
            // buttonCloseUdp
            // 
            this.buttonCloseUdp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCloseUdp.Location = new System.Drawing.Point(372, 33);
            this.buttonCloseUdp.Name = "buttonCloseUdp";
            this.buttonCloseUdp.Size = new System.Drawing.Size(75, 23);
            this.buttonCloseUdp.TabIndex = 6;
            this.buttonCloseUdp.Text = "Disconnect";
            this.buttonCloseUdp.UseVisualStyleBackColor = true;
            this.buttonCloseUdp.Click += new System.EventHandler(this.ButtonCloseUdp_Click);
            // 
            // buttonOpenUdp
            // 
            this.buttonOpenUdp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOpenUdp.Location = new System.Drawing.Point(372, 5);
            this.buttonOpenUdp.Name = "buttonOpenUdp";
            this.buttonOpenUdp.Size = new System.Drawing.Size(75, 23);
            this.buttonOpenUdp.TabIndex = 5;
            this.buttonOpenUdp.Text = "Connect";
            this.buttonOpenUdp.UseVisualStyleBackColor = true;
            this.buttonOpenUdp.Click += new System.EventHandler(this.ButtonOpenUdp_Click);
            // 
            // buttonSetupUdp
            // 
            this.buttonSetupUdp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSetupUdp.Location = new System.Drawing.Point(291, 5);
            this.buttonSetupUdp.Name = "buttonSetupUdp";
            this.buttonSetupUdp.Size = new System.Drawing.Size(75, 23);
            this.buttonSetupUdp.TabIndex = 4;
            this.buttonSetupUdp.Text = "Setup";
            this.buttonSetupUdp.UseVisualStyleBackColor = true;
            this.buttonSetupUdp.Click += new System.EventHandler(this.ButtonSetupUdp_Click);
            // 
            // textBoxRxPortUdp
            // 
            this.textBoxRxPortUdp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRxPortUdp.Location = new System.Drawing.Point(78, 7);
            this.textBoxRxPortUdp.Name = "textBoxRxPortUdp";
            this.textBoxRxPortUdp.Size = new System.Drawing.Size(207, 20);
            this.textBoxRxPortUdp.TabIndex = 3;
            this.textBoxRxPortUdp.Text = "60001";
            this.textBoxRxPortUdp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Local Port";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Message";
            // 
            // textBoxMsgUdp
            // 
            this.textBoxMsgUdp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxMsgUdp.Location = new System.Drawing.Point(78, 64);
            this.textBoxMsgUdp.Name = "textBoxMsgUdp";
            this.textBoxMsgUdp.Size = new System.Drawing.Size(207, 20);
            this.textBoxMsgUdp.TabIndex = 0;
            this.textBoxMsgUdp.Text = "UDPMessage";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.tabPage2.Controls.Add(this.buttonIsListeningTcp);
            this.tabPage2.Controls.Add(this.buttonGetIPTcp);
            this.tabPage2.Controls.Add(this.textBoxTxIPTcp);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.textBoxTxPortTcp);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.textBoxRxIPTcp);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.textBoxViewTcp);
            this.tabPage2.Controls.Add(this.buttonSendTcp);
            this.tabPage2.Controls.Add(this.buttonClearViewTcp);
            this.tabPage2.Controls.Add(this.buttonCloseTcp);
            this.tabPage2.Controls.Add(this.buttonOpenTcp);
            this.tabPage2.Controls.Add(this.buttonSetupTcp);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.textBoxMsgTcp);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(453, 361);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "TCP";
            // 
            // buttonIsListeningTcp
            // 
            this.buttonIsListeningTcp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonIsListeningTcp.Location = new System.Drawing.Point(372, 62);
            this.buttonIsListeningTcp.Name = "buttonIsListeningTcp";
            this.buttonIsListeningTcp.Size = new System.Drawing.Size(75, 23);
            this.buttonIsListeningTcp.TabIndex = 39;
            this.buttonIsListeningTcp.Text = "Connected";
            this.buttonIsListeningTcp.UseVisualStyleBackColor = true;
            this.buttonIsListeningTcp.Click += new System.EventHandler(this.ButtonIsListeningTcp_Click);
            // 
            // buttonGetIPTcp
            // 
            this.buttonGetIPTcp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonGetIPTcp.Location = new System.Drawing.Point(291, 33);
            this.buttonGetIPTcp.Name = "buttonGetIPTcp";
            this.buttonGetIPTcp.Size = new System.Drawing.Size(75, 23);
            this.buttonGetIPTcp.TabIndex = 37;
            this.buttonGetIPTcp.Text = "Get IP";
            this.buttonGetIPTcp.UseVisualStyleBackColor = true;
            this.buttonGetIPTcp.Click += new System.EventHandler(this.ButtonGetIPTcp_Click);
            // 
            // textBoxTxIPTcp
            // 
            this.textBoxTxIPTcp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxTxIPTcp.Location = new System.Drawing.Point(78, 121);
            this.textBoxTxIPTcp.Name = "textBoxTxIPTcp";
            this.textBoxTxIPTcp.Size = new System.Drawing.Size(207, 20);
            this.textBoxTxIPTcp.TabIndex = 36;
            this.textBoxTxIPTcp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 35;
            this.label3.Text = "Remote IP";
            // 
            // textBoxTxPortTcp
            // 
            this.textBoxTxPortTcp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxTxPortTcp.Location = new System.Drawing.Point(78, 93);
            this.textBoxTxPortTcp.Name = "textBoxTxPortTcp";
            this.textBoxTxPortTcp.Size = new System.Drawing.Size(207, 20);
            this.textBoxTxPortTcp.TabIndex = 34;
            this.textBoxTxPortTcp.Text = "60002";
            this.textBoxTxPortTcp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 33;
            this.label4.Text = "Remote Port";
            // 
            // textBoxRxIPTcp
            // 
            this.textBoxRxIPTcp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRxIPTcp.Location = new System.Drawing.Point(78, 35);
            this.textBoxRxIPTcp.Name = "textBoxRxIPTcp";
            this.textBoxRxIPTcp.Size = new System.Drawing.Size(207, 20);
            this.textBoxRxIPTcp.TabIndex = 32;
            this.textBoxRxIPTcp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(26, 38);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 31;
            this.label8.Text = "Local IP";
            // 
            // textBoxViewTcp
            // 
            this.textBoxViewTcp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxViewTcp.Location = new System.Drawing.Point(6, 148);
            this.textBoxViewTcp.Multiline = true;
            this.textBoxViewTcp.Name = "textBoxViewTcp";
            this.textBoxViewTcp.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxViewTcp.Size = new System.Drawing.Size(441, 207);
            this.textBoxViewTcp.TabIndex = 29;
            // 
            // buttonSendTcp
            // 
            this.buttonSendTcp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSendTcp.Location = new System.Drawing.Point(291, 91);
            this.buttonSendTcp.Name = "buttonSendTcp";
            this.buttonSendTcp.Size = new System.Drawing.Size(75, 23);
            this.buttonSendTcp.TabIndex = 28;
            this.buttonSendTcp.Text = "Send";
            this.buttonSendTcp.UseVisualStyleBackColor = true;
            this.buttonSendTcp.Click += new System.EventHandler(this.ButtonSendTcp_Click);
            // 
            // buttonClearViewTcp
            // 
            this.buttonClearViewTcp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClearViewTcp.Location = new System.Drawing.Point(372, 119);
            this.buttonClearViewTcp.Name = "buttonClearViewTcp";
            this.buttonClearViewTcp.Size = new System.Drawing.Size(75, 23);
            this.buttonClearViewTcp.TabIndex = 27;
            this.buttonClearViewTcp.Text = "ClearView";
            this.buttonClearViewTcp.UseVisualStyleBackColor = true;
            this.buttonClearViewTcp.Click += new System.EventHandler(this.ButtonClearViewTcp_Click);
            // 
            // buttonCloseTcp
            // 
            this.buttonCloseTcp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCloseTcp.Location = new System.Drawing.Point(372, 33);
            this.buttonCloseTcp.Name = "buttonCloseTcp";
            this.buttonCloseTcp.Size = new System.Drawing.Size(75, 23);
            this.buttonCloseTcp.TabIndex = 26;
            this.buttonCloseTcp.Text = "Disconnect";
            this.buttonCloseTcp.UseVisualStyleBackColor = true;
            this.buttonCloseTcp.Click += new System.EventHandler(this.ButtonCloseTcp_Click);
            // 
            // buttonOpenTcp
            // 
            this.buttonOpenTcp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOpenTcp.Location = new System.Drawing.Point(372, 5);
            this.buttonOpenTcp.Name = "buttonOpenTcp";
            this.buttonOpenTcp.Size = new System.Drawing.Size(75, 23);
            this.buttonOpenTcp.TabIndex = 25;
            this.buttonOpenTcp.Text = "Connect";
            this.buttonOpenTcp.UseVisualStyleBackColor = true;
            this.buttonOpenTcp.Click += new System.EventHandler(this.ButtonOpenTcp_Click);
            // 
            // buttonSetupTcp
            // 
            this.buttonSetupTcp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSetupTcp.Location = new System.Drawing.Point(291, 5);
            this.buttonSetupTcp.Name = "buttonSetupTcp";
            this.buttonSetupTcp.Size = new System.Drawing.Size(75, 23);
            this.buttonSetupTcp.TabIndex = 24;
            this.buttonSetupTcp.Text = "Setup";
            this.buttonSetupTcp.UseVisualStyleBackColor = true;
            this.buttonSetupTcp.Click += new System.EventHandler(this.ButtonSetupTcp_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(22, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "Message";
            // 
            // textBoxMsgTcp
            // 
            this.textBoxMsgTcp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxMsgTcp.Location = new System.Drawing.Point(78, 64);
            this.textBoxMsgTcp.Name = "textBoxMsgTcp";
            this.textBoxMsgTcp.Size = new System.Drawing.Size(207, 20);
            this.textBoxMsgTcp.TabIndex = 20;
            this.textBoxMsgTcp.Text = "TCPMessage";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage3.Controls.Add(this.checkBoxTCPSEcho);
            this.tabPage3.Controls.Add(this.buttonGetAuxIPTcpServer);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.textBoxMsgTcpServer);
            this.tabPage3.Controls.Add(this.buttonSendBroadcastTcpServer);
            this.tabPage3.Controls.Add(this.labelConnectionsTcp);
            this.tabPage3.Controls.Add(this.buttonCloseTcpServer);
            this.tabPage3.Controls.Add(this.textBoxViewTcpServer);
            this.tabPage3.Controls.Add(this.buttonClearViewTcpServer);
            this.tabPage3.Controls.Add(this.buttonIsListeningTcpServer);
            this.tabPage3.Controls.Add(this.buttonGetIPTcpServer);
            this.tabPage3.Controls.Add(this.textBoxRxIPTcpServer);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.buttonStartTcpServer);
            this.tabPage3.Controls.Add(this.buttonSetupTcpServer);
            this.tabPage3.Controls.Add(this.textBoxRxPortTcpServer);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(453, 361);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "TCP server";
            // 
            // checkBoxTCPSEcho
            // 
            this.checkBoxTCPSEcho.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxTCPSEcho.AutoSize = true;
            this.checkBoxTCPSEcho.Checked = true;
            this.checkBoxTCPSEcho.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxTCPSEcho.Location = new System.Drawing.Point(291, 96);
            this.checkBoxTCPSEcho.Name = "checkBoxTCPSEcho";
            this.checkBoxTCPSEcho.Size = new System.Drawing.Size(51, 17);
            this.checkBoxTCPSEcho.TabIndex = 58;
            this.checkBoxTCPSEcho.Text = "Echo";
            this.checkBoxTCPSEcho.UseVisualStyleBackColor = true;
            // 
            // buttonGetAuxIPTcpServer
            // 
            this.buttonGetAuxIPTcpServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonGetAuxIPTcpServer.Location = new System.Drawing.Point(291, 62);
            this.buttonGetAuxIPTcpServer.Name = "buttonGetAuxIPTcpServer";
            this.buttonGetAuxIPTcpServer.Size = new System.Drawing.Size(75, 23);
            this.buttonGetAuxIPTcpServer.TabIndex = 57;
            this.buttonGetAuxIPTcpServer.Text = "Get aux IP";
            this.buttonGetAuxIPTcpServer.UseVisualStyleBackColor = true;
            this.buttonGetAuxIPTcpServer.Click += new System.EventHandler(this.ButtonGetAuxIPTcpServer_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(22, 67);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 13);
            this.label14.TabIndex = 56;
            this.label14.Text = "Message";
            // 
            // textBoxMsgTcpServer
            // 
            this.textBoxMsgTcpServer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxMsgTcpServer.Location = new System.Drawing.Point(78, 64);
            this.textBoxMsgTcpServer.Name = "textBoxMsgTcpServer";
            this.textBoxMsgTcpServer.Size = new System.Drawing.Size(207, 20);
            this.textBoxMsgTcpServer.TabIndex = 55;
            this.textBoxMsgTcpServer.Text = "TCPServerMessage";
            // 
            // buttonSendBroadcastTcpServer
            // 
            this.buttonSendBroadcastTcpServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSendBroadcastTcpServer.Location = new System.Drawing.Point(291, 119);
            this.buttonSendBroadcastTcpServer.Name = "buttonSendBroadcastTcpServer";
            this.buttonSendBroadcastTcpServer.Size = new System.Drawing.Size(75, 23);
            this.buttonSendBroadcastTcpServer.TabIndex = 54;
            this.buttonSendBroadcastTcpServer.Text = "Distribute";
            this.buttonSendBroadcastTcpServer.UseVisualStyleBackColor = true;
            this.buttonSendBroadcastTcpServer.Click += new System.EventHandler(this.ButtonSendBroadcastTcpServer_Click);
            // 
            // labelConnectionsTcp
            // 
            this.labelConnectionsTcp.AutoSize = true;
            this.labelConnectionsTcp.Location = new System.Drawing.Point(6, 124);
            this.labelConnectionsTcp.Name = "labelConnectionsTcp";
            this.labelConnectionsTcp.Size = new System.Drawing.Size(69, 13);
            this.labelConnectionsTcp.TabIndex = 53;
            this.labelConnectionsTcp.Text = "Connections:";
            // 
            // buttonCloseTcpServer
            // 
            this.buttonCloseTcpServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCloseTcpServer.Location = new System.Drawing.Point(372, 33);
            this.buttonCloseTcpServer.Name = "buttonCloseTcpServer";
            this.buttonCloseTcpServer.Size = new System.Drawing.Size(75, 23);
            this.buttonCloseTcpServer.TabIndex = 51;
            this.buttonCloseTcpServer.Text = "Disconnect";
            this.buttonCloseTcpServer.UseVisualStyleBackColor = true;
            this.buttonCloseTcpServer.Click += new System.EventHandler(this.ButtonCloseTcpServer_Click);
            // 
            // textBoxViewTcpServer
            // 
            this.textBoxViewTcpServer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxViewTcpServer.Location = new System.Drawing.Point(6, 148);
            this.textBoxViewTcpServer.Multiline = true;
            this.textBoxViewTcpServer.Name = "textBoxViewTcpServer";
            this.textBoxViewTcpServer.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxViewTcpServer.Size = new System.Drawing.Size(441, 207);
            this.textBoxViewTcpServer.TabIndex = 50;
            // 
            // buttonClearViewTcpServer
            // 
            this.buttonClearViewTcpServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClearViewTcpServer.Location = new System.Drawing.Point(372, 119);
            this.buttonClearViewTcpServer.Name = "buttonClearViewTcpServer";
            this.buttonClearViewTcpServer.Size = new System.Drawing.Size(75, 23);
            this.buttonClearViewTcpServer.TabIndex = 49;
            this.buttonClearViewTcpServer.Text = "ClearView";
            this.buttonClearViewTcpServer.UseVisualStyleBackColor = true;
            this.buttonClearViewTcpServer.Click += new System.EventHandler(this.ButtonClearViewTcpServer_Click);
            // 
            // buttonIsListeningTcpServer
            // 
            this.buttonIsListeningTcpServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonIsListeningTcpServer.Location = new System.Drawing.Point(372, 62);
            this.buttonIsListeningTcpServer.Name = "buttonIsListeningTcpServer";
            this.buttonIsListeningTcpServer.Size = new System.Drawing.Size(75, 23);
            this.buttonIsListeningTcpServer.TabIndex = 48;
            this.buttonIsListeningTcpServer.Text = "Connected";
            this.buttonIsListeningTcpServer.UseVisualStyleBackColor = true;
            this.buttonIsListeningTcpServer.Click += new System.EventHandler(this.ButtonIsListeningTcpServer_Click);
            // 
            // buttonGetIPTcpServer
            // 
            this.buttonGetIPTcpServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonGetIPTcpServer.Location = new System.Drawing.Point(291, 33);
            this.buttonGetIPTcpServer.Name = "buttonGetIPTcpServer";
            this.buttonGetIPTcpServer.Size = new System.Drawing.Size(75, 23);
            this.buttonGetIPTcpServer.TabIndex = 47;
            this.buttonGetIPTcpServer.Text = "Get IP";
            this.buttonGetIPTcpServer.UseVisualStyleBackColor = true;
            this.buttonGetIPTcpServer.Click += new System.EventHandler(this.ButtonGetIPTcpServer_Click);
            // 
            // textBoxRxIPTcpServer
            // 
            this.textBoxRxIPTcpServer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRxIPTcpServer.Location = new System.Drawing.Point(78, 35);
            this.textBoxRxIPTcpServer.Name = "textBoxRxIPTcpServer";
            this.textBoxRxIPTcpServer.Size = new System.Drawing.Size(207, 20);
            this.textBoxRxIPTcpServer.TabIndex = 46;
            this.textBoxRxIPTcpServer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(26, 38);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 13);
            this.label11.TabIndex = 45;
            this.label11.Text = "Local IP";
            // 
            // buttonStartTcpServer
            // 
            this.buttonStartTcpServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonStartTcpServer.Location = new System.Drawing.Point(372, 5);
            this.buttonStartTcpServer.Name = "buttonStartTcpServer";
            this.buttonStartTcpServer.Size = new System.Drawing.Size(75, 23);
            this.buttonStartTcpServer.TabIndex = 43;
            this.buttonStartTcpServer.Text = "Connect";
            this.buttonStartTcpServer.UseVisualStyleBackColor = true;
            this.buttonStartTcpServer.Click += new System.EventHandler(this.ButtonStartTcpServer_Click);
            // 
            // buttonSetupTcpServer
            // 
            this.buttonSetupTcpServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSetupTcpServer.Location = new System.Drawing.Point(291, 5);
            this.buttonSetupTcpServer.Name = "buttonSetupTcpServer";
            this.buttonSetupTcpServer.Size = new System.Drawing.Size(75, 23);
            this.buttonSetupTcpServer.TabIndex = 42;
            this.buttonSetupTcpServer.Text = "Setup";
            this.buttonSetupTcpServer.UseVisualStyleBackColor = true;
            this.buttonSetupTcpServer.Click += new System.EventHandler(this.ButtonSetupTcpServer_Click);
            // 
            // textBoxRxPortTcpServer
            // 
            this.textBoxRxPortTcpServer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRxPortTcpServer.Location = new System.Drawing.Point(78, 7);
            this.textBoxRxPortTcpServer.Name = "textBoxRxPortTcpServer";
            this.textBoxRxPortTcpServer.Size = new System.Drawing.Size(207, 20);
            this.textBoxRxPortTcpServer.TabIndex = 41;
            this.textBoxRxPortTcpServer.Text = "60002";
            this.textBoxRxPortTcpServer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(17, 10);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 13);
            this.label12.TabIndex = 40;
            this.label12.Text = "Local Port";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage4.Controls.Add(this.buttonSetupWS);
            this.tabPage4.Controls.Add(this.buttonIsListeningWS);
            this.tabPage4.Controls.Add(this.buttonGetIPWS);
            this.tabPage4.Controls.Add(this.textBoxTxUrlWS);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.textBoxViewWS);
            this.tabPage4.Controls.Add(this.buttonSendWS);
            this.tabPage4.Controls.Add(this.buttonClearViewWS);
            this.tabPage4.Controls.Add(this.buttonCloseWS);
            this.tabPage4.Controls.Add(this.buttonOpenWS);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Controls.Add(this.textBoxMsgWS);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(453, 361);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "WS";
            // 
            // buttonSetupWS
            // 
            this.buttonSetupWS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSetupWS.Location = new System.Drawing.Point(291, 6);
            this.buttonSetupWS.Name = "buttonSetupWS";
            this.buttonSetupWS.Size = new System.Drawing.Size(75, 23);
            this.buttonSetupWS.TabIndex = 59;
            this.buttonSetupWS.Text = "Setup";
            this.buttonSetupWS.UseVisualStyleBackColor = true;
            this.buttonSetupWS.Click += new System.EventHandler(this.ButtonSetupWS_Click);
            // 
            // buttonIsListeningWS
            // 
            this.buttonIsListeningWS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonIsListeningWS.Location = new System.Drawing.Point(372, 63);
            this.buttonIsListeningWS.Name = "buttonIsListeningWS";
            this.buttonIsListeningWS.Size = new System.Drawing.Size(75, 23);
            this.buttonIsListeningWS.TabIndex = 58;
            this.buttonIsListeningWS.Text = "Connected";
            this.buttonIsListeningWS.UseVisualStyleBackColor = true;
            this.buttonIsListeningWS.Click += new System.EventHandler(this.ButtonIsListeningWS_Click);
            // 
            // buttonGetIPWS
            // 
            this.buttonGetIPWS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonGetIPWS.Location = new System.Drawing.Point(291, 34);
            this.buttonGetIPWS.Name = "buttonGetIPWS";
            this.buttonGetIPWS.Size = new System.Drawing.Size(75, 23);
            this.buttonGetIPWS.TabIndex = 57;
            this.buttonGetIPWS.Text = "Get URL";
            this.buttonGetIPWS.UseVisualStyleBackColor = true;
            this.buttonGetIPWS.Click += new System.EventHandler(this.ButtonGetIPWS_Click);
            // 
            // textBoxTxUrlWS
            // 
            this.textBoxTxUrlWS.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxTxUrlWS.Location = new System.Drawing.Point(78, 94);
            this.textBoxTxUrlWS.Name = "textBoxTxUrlWS";
            this.textBoxTxUrlWS.Size = new System.Drawing.Size(207, 20);
            this.textBoxTxUrlWS.TabIndex = 56;
            this.textBoxTxUrlWS.Text = "ws://[RemoteIP]:60003/";
            this.textBoxTxUrlWS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 97);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 13);
            this.label13.TabIndex = 55;
            this.label13.Text = "Remote URL";
            // 
            // textBoxViewWS
            // 
            this.textBoxViewWS.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxViewWS.Location = new System.Drawing.Point(6, 149);
            this.textBoxViewWS.Multiline = true;
            this.textBoxViewWS.Name = "textBoxViewWS";
            this.textBoxViewWS.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxViewWS.Size = new System.Drawing.Size(441, 207);
            this.textBoxViewWS.TabIndex = 49;
            // 
            // buttonSendWS
            // 
            this.buttonSendWS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSendWS.Location = new System.Drawing.Point(291, 92);
            this.buttonSendWS.Name = "buttonSendWS";
            this.buttonSendWS.Size = new System.Drawing.Size(75, 23);
            this.buttonSendWS.TabIndex = 48;
            this.buttonSendWS.Text = "Send";
            this.buttonSendWS.UseVisualStyleBackColor = true;
            this.buttonSendWS.Click += new System.EventHandler(this.ButtonSendWS_Click);
            // 
            // buttonClearViewWS
            // 
            this.buttonClearViewWS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClearViewWS.Location = new System.Drawing.Point(372, 120);
            this.buttonClearViewWS.Name = "buttonClearViewWS";
            this.buttonClearViewWS.Size = new System.Drawing.Size(75, 23);
            this.buttonClearViewWS.TabIndex = 47;
            this.buttonClearViewWS.Text = "ClearView";
            this.buttonClearViewWS.UseVisualStyleBackColor = true;
            this.buttonClearViewWS.Click += new System.EventHandler(this.ButtonClearViewWS_Click);
            // 
            // buttonCloseWS
            // 
            this.buttonCloseWS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCloseWS.Location = new System.Drawing.Point(372, 34);
            this.buttonCloseWS.Name = "buttonCloseWS";
            this.buttonCloseWS.Size = new System.Drawing.Size(75, 23);
            this.buttonCloseWS.TabIndex = 46;
            this.buttonCloseWS.Text = "Disconnect";
            this.buttonCloseWS.UseVisualStyleBackColor = true;
            this.buttonCloseWS.Click += new System.EventHandler(this.ButtonCloseWS_Click);
            // 
            // buttonOpenWS
            // 
            this.buttonOpenWS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOpenWS.Location = new System.Drawing.Point(372, 6);
            this.buttonOpenWS.Name = "buttonOpenWS";
            this.buttonOpenWS.Size = new System.Drawing.Size(75, 23);
            this.buttonOpenWS.TabIndex = 45;
            this.buttonOpenWS.Text = "Connect";
            this.buttonOpenWS.UseVisualStyleBackColor = true;
            this.buttonOpenWS.Click += new System.EventHandler(this.ButtonOpenWS_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(22, 67);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(50, 13);
            this.label17.TabIndex = 41;
            this.label17.Text = "Message";
            // 
            // textBoxMsgWS
            // 
            this.textBoxMsgWS.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxMsgWS.Location = new System.Drawing.Point(78, 65);
            this.textBoxMsgWS.Name = "textBoxMsgWS";
            this.textBoxMsgWS.Size = new System.Drawing.Size(207, 20);
            this.textBoxMsgWS.TabIndex = 40;
            this.textBoxMsgWS.Text = "WS Message";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tabPage5.Controls.Add(this.buttonGetAuxIPWsServer);
            this.tabPage5.Controls.Add(this.buttonGetIPWsServer);
            this.tabPage5.Controls.Add(this.checkBoxWSSEcho);
            this.tabPage5.Controls.Add(this.label16);
            this.tabPage5.Controls.Add(this.textBoxMsgWSServer);
            this.tabPage5.Controls.Add(this.buttonSendBroadcastWSServer);
            this.tabPage5.Controls.Add(this.labelConnectionsWs);
            this.tabPage5.Controls.Add(this.buttonCloseWsServer);
            this.tabPage5.Controls.Add(this.textBoxViewWsServer);
            this.tabPage5.Controls.Add(this.buttonClearViewWsServer);
            this.tabPage5.Controls.Add(this.buttonIsListeningWsServer);
            this.tabPage5.Controls.Add(this.textBoxRxIPWsServer);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.buttonStartWsServer);
            this.tabPage5.Controls.Add(this.buttonSetupWsServer);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(453, 361);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "WS server";
            // 
            // buttonGetAuxIPWsServer
            // 
            this.buttonGetAuxIPWsServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonGetAuxIPWsServer.Location = new System.Drawing.Point(291, 63);
            this.buttonGetAuxIPWsServer.Name = "buttonGetAuxIPWsServer";
            this.buttonGetAuxIPWsServer.Size = new System.Drawing.Size(75, 23);
            this.buttonGetAuxIPWsServer.TabIndex = 75;
            this.buttonGetAuxIPWsServer.Text = "Get aux IP";
            this.buttonGetAuxIPWsServer.UseVisualStyleBackColor = true;
            this.buttonGetAuxIPWsServer.Click += new System.EventHandler(this.buttonGetAuxIPWsServer_Click);
            // 
            // buttonGetIPWsServer
            // 
            this.buttonGetIPWsServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonGetIPWsServer.Location = new System.Drawing.Point(291, 34);
            this.buttonGetIPWsServer.Name = "buttonGetIPWsServer";
            this.buttonGetIPWsServer.Size = new System.Drawing.Size(75, 23);
            this.buttonGetIPWsServer.TabIndex = 74;
            this.buttonGetIPWsServer.Text = "Get IP";
            this.buttonGetIPWsServer.UseVisualStyleBackColor = true;
            this.buttonGetIPWsServer.Click += new System.EventHandler(this.buttonGetIPWsServer_Click);
            // 
            // checkBoxWSSEcho
            // 
            this.checkBoxWSSEcho.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxWSSEcho.AutoSize = true;
            this.checkBoxWSSEcho.Checked = true;
            this.checkBoxWSSEcho.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxWSSEcho.Location = new System.Drawing.Point(291, 97);
            this.checkBoxWSSEcho.Name = "checkBoxWSSEcho";
            this.checkBoxWSSEcho.Size = new System.Drawing.Size(51, 17);
            this.checkBoxWSSEcho.TabIndex = 71;
            this.checkBoxWSSEcho.Text = "Echo";
            this.checkBoxWSSEcho.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(22, 67);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(50, 13);
            this.label16.TabIndex = 70;
            this.label16.Text = "Message";
            // 
            // textBoxMsgWSServer
            // 
            this.textBoxMsgWSServer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxMsgWSServer.Location = new System.Drawing.Point(78, 65);
            this.textBoxMsgWSServer.Name = "textBoxMsgWSServer";
            this.textBoxMsgWSServer.Size = new System.Drawing.Size(207, 20);
            this.textBoxMsgWSServer.TabIndex = 69;
            this.textBoxMsgWSServer.Text = "WSServer Message";
            // 
            // buttonSendBroadcastWSServer
            // 
            this.buttonSendBroadcastWSServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSendBroadcastWSServer.Location = new System.Drawing.Point(291, 120);
            this.buttonSendBroadcastWSServer.Name = "buttonSendBroadcastWSServer";
            this.buttonSendBroadcastWSServer.Size = new System.Drawing.Size(75, 23);
            this.buttonSendBroadcastWSServer.TabIndex = 68;
            this.buttonSendBroadcastWSServer.Text = "Distribute";
            this.buttonSendBroadcastWSServer.UseVisualStyleBackColor = true;
            this.buttonSendBroadcastWSServer.Click += new System.EventHandler(this.ButtonSendBroadcastWSServer_Click);
            // 
            // labelConnectionsWs
            // 
            this.labelConnectionsWs.AutoSize = true;
            this.labelConnectionsWs.Location = new System.Drawing.Point(6, 125);
            this.labelConnectionsWs.Name = "labelConnectionsWs";
            this.labelConnectionsWs.Size = new System.Drawing.Size(69, 13);
            this.labelConnectionsWs.TabIndex = 67;
            this.labelConnectionsWs.Text = "Connections:";
            // 
            // buttonCloseWsServer
            // 
            this.buttonCloseWsServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCloseWsServer.Location = new System.Drawing.Point(372, 34);
            this.buttonCloseWsServer.Name = "buttonCloseWsServer";
            this.buttonCloseWsServer.Size = new System.Drawing.Size(75, 22);
            this.buttonCloseWsServer.TabIndex = 65;
            this.buttonCloseWsServer.Text = "Disconnect";
            this.buttonCloseWsServer.UseVisualStyleBackColor = true;
            this.buttonCloseWsServer.Click += new System.EventHandler(this.ButtonCloseWsServer_Click);
            // 
            // textBoxViewWsServer
            // 
            this.textBoxViewWsServer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxViewWsServer.Location = new System.Drawing.Point(6, 149);
            this.textBoxViewWsServer.Multiline = true;
            this.textBoxViewWsServer.Name = "textBoxViewWsServer";
            this.textBoxViewWsServer.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxViewWsServer.Size = new System.Drawing.Size(441, 206);
            this.textBoxViewWsServer.TabIndex = 64;
            // 
            // buttonClearViewWsServer
            // 
            this.buttonClearViewWsServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClearViewWsServer.Location = new System.Drawing.Point(372, 120);
            this.buttonClearViewWsServer.Name = "buttonClearViewWsServer";
            this.buttonClearViewWsServer.Size = new System.Drawing.Size(75, 22);
            this.buttonClearViewWsServer.TabIndex = 63;
            this.buttonClearViewWsServer.Text = "ClearView";
            this.buttonClearViewWsServer.UseVisualStyleBackColor = true;
            this.buttonClearViewWsServer.Click += new System.EventHandler(this.ButtonClearViewWsServer_Click);
            // 
            // buttonIsListeningWsServer
            // 
            this.buttonIsListeningWsServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonIsListeningWsServer.Location = new System.Drawing.Point(372, 63);
            this.buttonIsListeningWsServer.Name = "buttonIsListeningWsServer";
            this.buttonIsListeningWsServer.Size = new System.Drawing.Size(75, 22);
            this.buttonIsListeningWsServer.TabIndex = 62;
            this.buttonIsListeningWsServer.Text = "Connected";
            this.buttonIsListeningWsServer.UseVisualStyleBackColor = true;
            this.buttonIsListeningWsServer.Click += new System.EventHandler(this.ButtonIsListeningWsServer_Click);
            // 
            // textBoxRxIPWsServer
            // 
            this.textBoxRxIPWsServer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRxIPWsServer.Location = new System.Drawing.Point(78, 36);
            this.textBoxRxIPWsServer.Name = "textBoxRxIPWsServer";
            this.textBoxRxIPWsServer.Size = new System.Drawing.Size(207, 20);
            this.textBoxRxIPWsServer.TabIndex = 60;
            this.textBoxRxIPWsServer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(22, 39);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(58, 13);
            this.label15.TabIndex = 59;
            this.label15.Text = "Local URL";
            // 
            // buttonStartWsServer
            // 
            this.buttonStartWsServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonStartWsServer.Location = new System.Drawing.Point(372, 6);
            this.buttonStartWsServer.Name = "buttonStartWsServer";
            this.buttonStartWsServer.Size = new System.Drawing.Size(75, 22);
            this.buttonStartWsServer.TabIndex = 57;
            this.buttonStartWsServer.Text = "Connect";
            this.buttonStartWsServer.UseVisualStyleBackColor = true;
            this.buttonStartWsServer.Click += new System.EventHandler(this.ButtonStartWsServer_Click);
            // 
            // buttonSetupWsServer
            // 
            this.buttonSetupWsServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSetupWsServer.Location = new System.Drawing.Point(291, 6);
            this.buttonSetupWsServer.Name = "buttonSetupWsServer";
            this.buttonSetupWsServer.Size = new System.Drawing.Size(75, 22);
            this.buttonSetupWsServer.TabIndex = 56;
            this.buttonSetupWsServer.Text = "Setup";
            this.buttonSetupWsServer.UseVisualStyleBackColor = true;
            this.buttonSetupWsServer.Click += new System.EventHandler(this.ButtonSetupWsServer_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tabPage6.Controls.Add(this.groupBoxWSRepeater);
            this.tabPage6.Controls.Add(this.groupBoxTCPRepeater);
            this.tabPage6.Controls.Add(this.groupBoxUDPRepeater);
            this.tabPage6.Controls.Add(this.labelRealTime);
            this.tabPage6.Controls.Add(this.progressBarTime);
            this.tabPage6.Controls.Add(this.buttonWSRequest);
            this.tabPage6.Controls.Add(this.buttonTCPRequest);
            this.tabPage6.Controls.Add(this.buttonUDPRequest);
            this.tabPage6.Controls.Add(this.label18);
            this.tabPage6.Controls.Add(this.label9);
            this.tabPage6.Controls.Add(this.textBoxNTPServerPort);
            this.tabPage6.Controls.Add(this.textBoxNTPServerUrl);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(453, 361);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "NTP";
            // 
            // groupBoxWSRepeater
            // 
            this.groupBoxWSRepeater.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxWSRepeater.Controls.Add(this.checkBoxWSEmu);
            this.groupBoxWSRepeater.Controls.Add(this.pictureBoxWSR);
            this.groupBoxWSRepeater.Controls.Add(this.buttonWSRStop);
            this.groupBoxWSRepeater.Controls.Add(this.buttonWSRStart);
            this.groupBoxWSRepeater.Controls.Add(this.labelWSRAddress);
            this.groupBoxWSRepeater.Controls.Add(this.textBoxWSRAddress);
            this.groupBoxWSRepeater.Location = new System.Drawing.Point(6, 281);
            this.groupBoxWSRepeater.Name = "groupBoxWSRepeater";
            this.groupBoxWSRepeater.Size = new System.Drawing.Size(438, 74);
            this.groupBoxWSRepeater.TabIndex = 11;
            this.groupBoxWSRepeater.TabStop = false;
            this.groupBoxWSRepeater.Text = "Local WS repeater";
            // 
            // checkBoxWSEmu
            // 
            this.checkBoxWSEmu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxWSEmu.AutoSize = true;
            this.checkBoxWSEmu.Checked = true;
            this.checkBoxWSEmu.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxWSEmu.Location = new System.Drawing.Point(360, 21);
            this.checkBoxWSEmu.Name = "checkBoxWSEmu";
            this.checkBoxWSEmu.Size = new System.Drawing.Size(72, 17);
            this.checkBoxWSEmu.TabIndex = 10;
            this.checkBoxWSEmu.Text = "NTP Emu";
            this.checkBoxWSEmu.UseVisualStyleBackColor = true;
            // 
            // pictureBoxWSR
            // 
            this.pictureBoxWSR.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxWSR.BackColor = System.Drawing.Color.Red;
            this.pictureBoxWSR.Location = new System.Drawing.Point(330, 45);
            this.pictureBoxWSR.Name = "pictureBoxWSR";
            this.pictureBoxWSR.Size = new System.Drawing.Size(21, 22);
            this.pictureBoxWSR.TabIndex = 7;
            this.pictureBoxWSR.TabStop = false;
            // 
            // buttonWSRStop
            // 
            this.buttonWSRStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonWSRStop.Location = new System.Drawing.Point(357, 45);
            this.buttonWSRStop.Name = "buttonWSRStop";
            this.buttonWSRStop.Size = new System.Drawing.Size(75, 23);
            this.buttonWSRStop.TabIndex = 6;
            this.buttonWSRStop.Text = "Stop";
            this.buttonWSRStop.UseVisualStyleBackColor = true;
            this.buttonWSRStop.Click += new System.EventHandler(this.buttonWSRStop_Click);
            // 
            // buttonWSRStart
            // 
            this.buttonWSRStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonWSRStart.Location = new System.Drawing.Point(249, 45);
            this.buttonWSRStart.Name = "buttonWSRStart";
            this.buttonWSRStart.Size = new System.Drawing.Size(75, 23);
            this.buttonWSRStart.TabIndex = 5;
            this.buttonWSRStart.Text = "Start";
            this.buttonWSRStart.UseVisualStyleBackColor = true;
            this.buttonWSRStart.Click += new System.EventHandler(this.buttonWSRStart_Click);
            // 
            // labelWSRAddress
            // 
            this.labelWSRAddress.AutoSize = true;
            this.labelWSRAddress.Location = new System.Drawing.Point(6, 22);
            this.labelWSRAddress.Name = "labelWSRAddress";
            this.labelWSRAddress.Size = new System.Drawing.Size(98, 13);
            this.labelWSRAddress.TabIndex = 3;
            this.labelWSRAddress.Text = "Local NTP address";
            // 
            // textBoxWSRAddress
            // 
            this.textBoxWSRAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxWSRAddress.Location = new System.Drawing.Point(110, 19);
            this.textBoxWSRAddress.Name = "textBoxWSRAddress";
            this.textBoxWSRAddress.Size = new System.Drawing.Size(241, 20);
            this.textBoxWSRAddress.TabIndex = 1;
            // 
            // groupBoxTCPRepeater
            // 
            this.groupBoxTCPRepeater.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxTCPRepeater.Controls.Add(this.checkBoxTCPEmu);
            this.groupBoxTCPRepeater.Controls.Add(this.pictureBoxTCPR);
            this.groupBoxTCPRepeater.Controls.Add(this.buttonTCPRStop);
            this.groupBoxTCPRepeater.Controls.Add(this.buttonTCPRStart);
            this.groupBoxTCPRepeater.Controls.Add(this.labelTCPRPort);
            this.groupBoxTCPRepeater.Controls.Add(this.labelTCPRAddress);
            this.groupBoxTCPRepeater.Controls.Add(this.textBoxTCPRPort);
            this.groupBoxTCPRepeater.Controls.Add(this.textBoxTCPRAddress);
            this.groupBoxTCPRepeater.Location = new System.Drawing.Point(6, 201);
            this.groupBoxTCPRepeater.Name = "groupBoxTCPRepeater";
            this.groupBoxTCPRepeater.Size = new System.Drawing.Size(438, 74);
            this.groupBoxTCPRepeater.TabIndex = 10;
            this.groupBoxTCPRepeater.TabStop = false;
            this.groupBoxTCPRepeater.Text = "Local TCP repeater";
            // 
            // checkBoxTCPEmu
            // 
            this.checkBoxTCPEmu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxTCPEmu.AutoSize = true;
            this.checkBoxTCPEmu.Checked = true;
            this.checkBoxTCPEmu.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxTCPEmu.Location = new System.Drawing.Point(360, 21);
            this.checkBoxTCPEmu.Name = "checkBoxTCPEmu";
            this.checkBoxTCPEmu.Size = new System.Drawing.Size(72, 17);
            this.checkBoxTCPEmu.TabIndex = 9;
            this.checkBoxTCPEmu.Text = "NTP Emu";
            this.checkBoxTCPEmu.UseVisualStyleBackColor = true;
            // 
            // pictureBoxTCPR
            // 
            this.pictureBoxTCPR.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxTCPR.BackColor = System.Drawing.Color.Red;
            this.pictureBoxTCPR.Location = new System.Drawing.Point(330, 45);
            this.pictureBoxTCPR.Name = "pictureBoxTCPR";
            this.pictureBoxTCPR.Size = new System.Drawing.Size(21, 22);
            this.pictureBoxTCPR.TabIndex = 7;
            this.pictureBoxTCPR.TabStop = false;
            // 
            // buttonTCPRStop
            // 
            this.buttonTCPRStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonTCPRStop.Location = new System.Drawing.Point(357, 45);
            this.buttonTCPRStop.Name = "buttonTCPRStop";
            this.buttonTCPRStop.Size = new System.Drawing.Size(75, 23);
            this.buttonTCPRStop.TabIndex = 6;
            this.buttonTCPRStop.Text = "Stop";
            this.buttonTCPRStop.UseVisualStyleBackColor = true;
            this.buttonTCPRStop.Click += new System.EventHandler(this.buttonTCPRStop_Click);
            // 
            // buttonTCPRStart
            // 
            this.buttonTCPRStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonTCPRStart.Location = new System.Drawing.Point(249, 45);
            this.buttonTCPRStart.Name = "buttonTCPRStart";
            this.buttonTCPRStart.Size = new System.Drawing.Size(75, 23);
            this.buttonTCPRStart.TabIndex = 5;
            this.buttonTCPRStart.Text = "Start";
            this.buttonTCPRStart.UseVisualStyleBackColor = true;
            this.buttonTCPRStart.Click += new System.EventHandler(this.buttonTCPRStart_Click);
            // 
            // labelTCPRPort
            // 
            this.labelTCPRPort.AutoSize = true;
            this.labelTCPRPort.Location = new System.Drawing.Point(6, 50);
            this.labelTCPRPort.Name = "labelTCPRPort";
            this.labelTCPRPort.Size = new System.Drawing.Size(79, 13);
            this.labelTCPRPort.TabIndex = 4;
            this.labelTCPRPort.Text = "Local NTP port";
            // 
            // labelTCPRAddress
            // 
            this.labelTCPRAddress.AutoSize = true;
            this.labelTCPRAddress.Location = new System.Drawing.Point(6, 22);
            this.labelTCPRAddress.Name = "labelTCPRAddress";
            this.labelTCPRAddress.Size = new System.Drawing.Size(98, 13);
            this.labelTCPRAddress.TabIndex = 3;
            this.labelTCPRAddress.Text = "Local NTP address";
            // 
            // textBoxTCPRPort
            // 
            this.textBoxTCPRPort.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxTCPRPort.Location = new System.Drawing.Point(110, 47);
            this.textBoxTCPRPort.MaxLength = 5;
            this.textBoxTCPRPort.Name = "textBoxTCPRPort";
            this.textBoxTCPRPort.Size = new System.Drawing.Size(133, 20);
            this.textBoxTCPRPort.TabIndex = 2;
            this.textBoxTCPRPort.Text = "60011";
            // 
            // textBoxTCPRAddress
            // 
            this.textBoxTCPRAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxTCPRAddress.Location = new System.Drawing.Point(110, 19);
            this.textBoxTCPRAddress.Name = "textBoxTCPRAddress";
            this.textBoxTCPRAddress.Size = new System.Drawing.Size(241, 20);
            this.textBoxTCPRAddress.TabIndex = 1;
            // 
            // groupBoxUDPRepeater
            // 
            this.groupBoxUDPRepeater.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxUDPRepeater.Controls.Add(this.checkBoxUDPEmu);
            this.groupBoxUDPRepeater.Controls.Add(this.pictureBoxUDPR);
            this.groupBoxUDPRepeater.Controls.Add(this.buttonUDPRStop);
            this.groupBoxUDPRepeater.Controls.Add(this.buttonUDPRStart);
            this.groupBoxUDPRepeater.Controls.Add(this.labelUDPRPort);
            this.groupBoxUDPRepeater.Controls.Add(this.labelUDPRAddress);
            this.groupBoxUDPRepeater.Controls.Add(this.textBoxUDPRPort);
            this.groupBoxUDPRepeater.Controls.Add(this.textBoxUDPRAddress);
            this.groupBoxUDPRepeater.Location = new System.Drawing.Point(6, 121);
            this.groupBoxUDPRepeater.Name = "groupBoxUDPRepeater";
            this.groupBoxUDPRepeater.Size = new System.Drawing.Size(438, 74);
            this.groupBoxUDPRepeater.TabIndex = 9;
            this.groupBoxUDPRepeater.TabStop = false;
            this.groupBoxUDPRepeater.Text = "Local UDP repeater";
            // 
            // checkBoxUDPEmu
            // 
            this.checkBoxUDPEmu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxUDPEmu.AutoSize = true;
            this.checkBoxUDPEmu.Checked = true;
            this.checkBoxUDPEmu.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxUDPEmu.Location = new System.Drawing.Point(360, 21);
            this.checkBoxUDPEmu.Name = "checkBoxUDPEmu";
            this.checkBoxUDPEmu.Size = new System.Drawing.Size(72, 17);
            this.checkBoxUDPEmu.TabIndex = 8;
            this.checkBoxUDPEmu.Text = "NTP Emu";
            this.checkBoxUDPEmu.UseVisualStyleBackColor = true;
            // 
            // pictureBoxUDPR
            // 
            this.pictureBoxUDPR.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxUDPR.BackColor = System.Drawing.Color.Red;
            this.pictureBoxUDPR.Location = new System.Drawing.Point(330, 45);
            this.pictureBoxUDPR.Name = "pictureBoxUDPR";
            this.pictureBoxUDPR.Size = new System.Drawing.Size(21, 22);
            this.pictureBoxUDPR.TabIndex = 7;
            this.pictureBoxUDPR.TabStop = false;
            // 
            // buttonUDPRStop
            // 
            this.buttonUDPRStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonUDPRStop.Location = new System.Drawing.Point(357, 45);
            this.buttonUDPRStop.Name = "buttonUDPRStop";
            this.buttonUDPRStop.Size = new System.Drawing.Size(75, 23);
            this.buttonUDPRStop.TabIndex = 6;
            this.buttonUDPRStop.Text = "Stop";
            this.buttonUDPRStop.UseVisualStyleBackColor = true;
            this.buttonUDPRStop.Click += new System.EventHandler(this.buttonUDPRstop_Click);
            // 
            // buttonUDPRStart
            // 
            this.buttonUDPRStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonUDPRStart.Location = new System.Drawing.Point(249, 45);
            this.buttonUDPRStart.Name = "buttonUDPRStart";
            this.buttonUDPRStart.Size = new System.Drawing.Size(75, 23);
            this.buttonUDPRStart.TabIndex = 5;
            this.buttonUDPRStart.Text = "Start";
            this.buttonUDPRStart.UseVisualStyleBackColor = true;
            this.buttonUDPRStart.Click += new System.EventHandler(this.buttonUDPRStart_Click);
            // 
            // labelUDPRPort
            // 
            this.labelUDPRPort.AutoSize = true;
            this.labelUDPRPort.Location = new System.Drawing.Point(6, 50);
            this.labelUDPRPort.Name = "labelUDPRPort";
            this.labelUDPRPort.Size = new System.Drawing.Size(79, 13);
            this.labelUDPRPort.TabIndex = 4;
            this.labelUDPRPort.Text = "Local NTP port";
            // 
            // labelUDPRAddress
            // 
            this.labelUDPRAddress.AutoSize = true;
            this.labelUDPRAddress.Location = new System.Drawing.Point(6, 22);
            this.labelUDPRAddress.Name = "labelUDPRAddress";
            this.labelUDPRAddress.Size = new System.Drawing.Size(98, 13);
            this.labelUDPRAddress.TabIndex = 3;
            this.labelUDPRAddress.Text = "Local NTP address";
            // 
            // textBoxUDPRPort
            // 
            this.textBoxUDPRPort.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxUDPRPort.Location = new System.Drawing.Point(110, 47);
            this.textBoxUDPRPort.MaxLength = 5;
            this.textBoxUDPRPort.Name = "textBoxUDPRPort";
            this.textBoxUDPRPort.Size = new System.Drawing.Size(133, 20);
            this.textBoxUDPRPort.TabIndex = 2;
            this.textBoxUDPRPort.Text = "60010";
            // 
            // textBoxUDPRAddress
            // 
            this.textBoxUDPRAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxUDPRAddress.Location = new System.Drawing.Point(110, 19);
            this.textBoxUDPRAddress.Name = "textBoxUDPRAddress";
            this.textBoxUDPRAddress.Size = new System.Drawing.Size(241, 20);
            this.textBoxUDPRAddress.TabIndex = 1;
            // 
            // labelRealTime
            // 
            this.labelRealTime.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelRealTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRealTime.Location = new System.Drawing.Point(3, 80);
            this.labelRealTime.Name = "labelRealTime";
            this.labelRealTime.Size = new System.Drawing.Size(240, 23);
            this.labelRealTime.TabIndex = 8;
            this.labelRealTime.Text = "Real time: hh:mm:ss.fff (status)";
            // 
            // progressBarTime
            // 
            this.progressBarTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBarTime.Location = new System.Drawing.Point(249, 80);
            this.progressBarTime.Name = "progressBarTime";
            this.progressBarTime.Size = new System.Drawing.Size(198, 23);
            this.progressBarTime.Step = 0;
            this.progressBarTime.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBarTime.TabIndex = 7;
            this.progressBarTime.Value = 50;
            // 
            // buttonWSRequest
            // 
            this.buttonWSRequest.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonWSRequest.Location = new System.Drawing.Point(351, 32);
            this.buttonWSRequest.Name = "buttonWSRequest";
            this.buttonWSRequest.Size = new System.Drawing.Size(96, 23);
            this.buttonWSRequest.TabIndex = 6;
            this.buttonWSRequest.Text = "WS request";
            this.buttonWSRequest.UseVisualStyleBackColor = true;
            this.buttonWSRequest.Click += new System.EventHandler(this.buttonWSRequest_Click);
            // 
            // buttonTCPRequest
            // 
            this.buttonTCPRequest.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonTCPRequest.Location = new System.Drawing.Point(249, 32);
            this.buttonTCPRequest.Name = "buttonTCPRequest";
            this.buttonTCPRequest.Size = new System.Drawing.Size(96, 23);
            this.buttonTCPRequest.TabIndex = 5;
            this.buttonTCPRequest.Text = "TCP request";
            this.buttonTCPRequest.UseVisualStyleBackColor = true;
            this.buttonTCPRequest.Click += new System.EventHandler(this.buttonTCPRequest_Click);
            // 
            // buttonUDPRequest
            // 
            this.buttonUDPRequest.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonUDPRequest.Location = new System.Drawing.Point(147, 32);
            this.buttonUDPRequest.Name = "buttonUDPRequest";
            this.buttonUDPRequest.Size = new System.Drawing.Size(96, 23);
            this.buttonUDPRequest.TabIndex = 4;
            this.buttonUDPRequest.Text = "UDP request";
            this.buttonUDPRequest.UseVisualStyleBackColor = true;
            this.buttonUDPRequest.Click += new System.EventHandler(this.buttonUDPRequest_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 37);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(82, 13);
            this.label18.TabIndex = 3;
            this.label18.Text = "NTP server port";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 13);
            this.label9.TabIndex = 2;
            this.label9.Text = "NTP server address";
            // 
            // textBoxNTPServerPort
            // 
            this.textBoxNTPServerPort.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxNTPServerPort.Location = new System.Drawing.Point(94, 34);
            this.textBoxNTPServerPort.MaxLength = 5;
            this.textBoxNTPServerPort.Name = "textBoxNTPServerPort";
            this.textBoxNTPServerPort.Size = new System.Drawing.Size(47, 20);
            this.textBoxNTPServerPort.TabIndex = 1;
            this.textBoxNTPServerPort.Text = "123";
            // 
            // textBoxNTPServerUrl
            // 
            this.textBoxNTPServerUrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxNTPServerUrl.Location = new System.Drawing.Point(116, 6);
            this.textBoxNTPServerUrl.Name = "textBoxNTPServerUrl";
            this.textBoxNTPServerUrl.Size = new System.Drawing.Size(331, 20);
            this.textBoxNTPServerUrl.TabIndex = 0;
            // 
            // timerNTPClient
            // 
            this.timerNTPClient.Enabled = true;
            this.timerNTPClient.Tick += new System.EventHandler(this.timerNTPClient_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 411);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MinimumSize = new System.Drawing.Size(500, 450);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sockets Under Control";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.groupBoxWSRepeater.ResumeLayout(false);
            this.groupBoxWSRepeater.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWSR)).EndInit();
            this.groupBoxTCPRepeater.ResumeLayout(false);
            this.groupBoxTCPRepeater.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTCPR)).EndInit();
            this.groupBoxUDPRepeater.ResumeLayout(false);
            this.groupBoxUDPRepeater.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUDPR)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBoxMsgUdp;
        private System.Windows.Forms.Button buttonSendUdp;
        private System.Windows.Forms.Button buttonClearViewUdp;
        private System.Windows.Forms.Button buttonCloseUdp;
        private System.Windows.Forms.Button buttonOpenUdp;
        private System.Windows.Forms.Button buttonSetupUdp;
        private System.Windows.Forms.TextBox textBoxRxPortUdp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxViewUdp;
        private System.Windows.Forms.Button buttonBufferUdp;
        private System.Windows.Forms.TextBox textBoxTxIPUdp;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxTxPortUdp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxRxIPUdp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonSendBroadcastUdp;
        private System.Windows.Forms.Button buttonGetIPUdp;
        private System.Windows.Forms.Button buttonIsListeningUdp;
        private System.Windows.Forms.Button buttonIsListeningTcp;
        private System.Windows.Forms.Button buttonGetIPTcp;
        private System.Windows.Forms.TextBox textBoxTxIPTcp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxTxPortTcp;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxRxIPTcp;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxViewTcp;
        private System.Windows.Forms.Button buttonSendTcp;
        private System.Windows.Forms.Button buttonClearViewTcp;
        private System.Windows.Forms.Button buttonCloseTcp;
        private System.Windows.Forms.Button buttonOpenTcp;
        private System.Windows.Forms.Button buttonSetupTcp;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxMsgTcp;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox textBoxViewTcpServer;
        private System.Windows.Forms.Button buttonClearViewTcpServer;
        private System.Windows.Forms.Button buttonIsListeningTcpServer;
        private System.Windows.Forms.Button buttonGetIPTcpServer;
        private System.Windows.Forms.TextBox textBoxRxIPTcpServer;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonStartTcpServer;
        private System.Windows.Forms.Button buttonSetupTcpServer;
        private System.Windows.Forms.TextBox textBoxRxPortTcpServer;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button buttonCloseTcpServer;
        private System.Windows.Forms.Label labelConnectionsTcp;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button buttonIsListeningWS;
        private System.Windows.Forms.Button buttonGetIPWS;
        private System.Windows.Forms.TextBox textBoxTxUrlWS;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxViewWS;
        private System.Windows.Forms.Button buttonSendWS;
        private System.Windows.Forms.Button buttonClearViewWS;
        private System.Windows.Forms.Button buttonCloseWS;
        private System.Windows.Forms.Button buttonOpenWS;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBoxMsgWS;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label labelConnectionsWs;
        private System.Windows.Forms.Button buttonCloseWsServer;
        private System.Windows.Forms.TextBox textBoxViewWsServer;
        private System.Windows.Forms.Button buttonClearViewWsServer;
        private System.Windows.Forms.Button buttonIsListeningWsServer;
        private System.Windows.Forms.TextBox textBoxRxIPWsServer;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button buttonStartWsServer;
        private System.Windows.Forms.Button buttonSetupWsServer;
        private System.Windows.Forms.Button buttonSetupWS;
        private System.Windows.Forms.Button buttonSendBroadcastTcpServer;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxMsgTcpServer;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxMsgWSServer;
        private System.Windows.Forms.Button buttonSendBroadcastWSServer;
        private System.Windows.Forms.Button buttonGetAuxIPUdp;
        private System.Windows.Forms.Button buttonGetAuxIPTcpServer;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxNTPServerPort;
        private System.Windows.Forms.TextBox textBoxNTPServerUrl;
        private System.Windows.Forms.Button buttonWSRequest;
        private System.Windows.Forms.Button buttonTCPRequest;
        private System.Windows.Forms.Button buttonUDPRequest;
        private System.Windows.Forms.Label labelRealTime;
        private System.Windows.Forms.ProgressBar progressBarTime;
        private System.Windows.Forms.GroupBox groupBoxUDPRepeater;
        private System.Windows.Forms.PictureBox pictureBoxUDPR;
        private System.Windows.Forms.Button buttonUDPRStop;
        private System.Windows.Forms.Button buttonUDPRStart;
        private System.Windows.Forms.Label labelUDPRPort;
        private System.Windows.Forms.Label labelUDPRAddress;
        private System.Windows.Forms.TextBox textBoxUDPRPort;
        private System.Windows.Forms.TextBox textBoxUDPRAddress;
        private System.Windows.Forms.Timer timerNTPClient;
        private System.Windows.Forms.GroupBox groupBoxWSRepeater;
        private System.Windows.Forms.PictureBox pictureBoxWSR;
        private System.Windows.Forms.Button buttonWSRStop;
        private System.Windows.Forms.Button buttonWSRStart;
        private System.Windows.Forms.Label labelWSRAddress;
        private System.Windows.Forms.TextBox textBoxWSRAddress;
        private System.Windows.Forms.GroupBox groupBoxTCPRepeater;
        private System.Windows.Forms.PictureBox pictureBoxTCPR;
        private System.Windows.Forms.Button buttonTCPRStop;
        private System.Windows.Forms.Button buttonTCPRStart;
        private System.Windows.Forms.Label labelTCPRPort;
        private System.Windows.Forms.Label labelTCPRAddress;
        private System.Windows.Forms.TextBox textBoxTCPRPort;
        private System.Windows.Forms.TextBox textBoxTCPRAddress;
        private System.Windows.Forms.CheckBox checkBoxWSEmu;
        private System.Windows.Forms.CheckBox checkBoxTCPEmu;
        private System.Windows.Forms.CheckBox checkBoxUDPEmu;
        private System.Windows.Forms.CheckBox checkBoxTCPSEcho;
        private System.Windows.Forms.CheckBox checkBoxWSSEcho;
        private System.Windows.Forms.Button buttonGetAuxIPWsServer;
        private System.Windows.Forms.Button buttonGetIPWsServer;
    }
}

